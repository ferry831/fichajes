<?php namespace App\Http\Controllers;

class Inicio extends Controller {

	public static $permisos = ['inicio_sesion'];

	public function index(){
		return view('plantilla');
	}

}
