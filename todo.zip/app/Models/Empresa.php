<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
class Empresa extends Model {
	protected $table = 'empresas';

	public static function generarTokenAutologin(){
		do {
			$token = sha1(uniqid().time());
			$repetido = Empresa::where('token_autologin', $token)->exists();
		} while($repetido);
		return $token;
	}

}
