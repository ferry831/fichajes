<div class="modal fade" id="nuevoTrabajador" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form class="form-horizontal" role="form" method="post" action="<?=\URL::action('Trabajadores@postNuevo')?>">
        <div class="modal-header">
          <h4 class="modal-title"><?=trans('base.nuevo_trabajador')?></h4>
        </div>
        <div class="modal-body">
          <input type="hidden" name="_token" value="<?=csrf_token()?>">
          <?

            $inline = true;

            $nombre = 'nombre';
            $label = trans('base.nombre');
            $requerido = true;
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

            $nombre = 'apellidos';
            $label = trans('base.apellidos');
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

						$nombre = 'nif';
            $label = trans('base.nif');
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

						$nombre = 'afiliacion';
            $label = trans('base.afiliacion');
            echo view('ui/input', compact('nombre', 'label', 'inline'));

					?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal"><?=trans('base.cerrar')?></button>
          <?=view('ui/submit', ['label' => trans('base.crear_trabajador')])?>
        </div>
      </form>
    </div>
  </div>
</div>
