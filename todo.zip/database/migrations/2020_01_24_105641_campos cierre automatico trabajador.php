<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CamposCierreAutomaticoTrabajador extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('trabajadores', function($table){
			$table->boolean('cierre_automatico_horario')->after('hora_cierre')->default(0);
			$table->integer('turno_maximo')->after('cierre_automatico_horario')->default(0);
			$table->boolean('cierre_automatico_turno')->after('turno_maximo')->default(0);
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('trabajadores', function($table){
			$table->dropColumn('cierre_automatico_horario');
			$table->dropColumn('turno_maximo');
			$table->dropColumn('cierre_automatico_turno');
		});
	}

}
