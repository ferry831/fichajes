<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Usuarios extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up(){

		Schema::create('usuarios', function(Blueprint $table){
			$table->bigIncrements('id');
			$table->string('nombre');
			$table->string('apellidos');
			$table->string('email')->unique();
			$table->string('password', 60);
			$table->string('perfil');
			$table->rememberToken();
			$table->string('reset_token', 60)->index()->nullable();
			$table->datetime('reset_token_time')->nullable();
			$table->timestamps();
		});

		Schema::create('permisos_usuario', function(Blueprint $table){
			$table->bigInteger('id_usuario')->unsigned()->index();
			$table->foreign('id_usuario')->references('id')->on('usuarios')->onDelete('cascade');
			$table->string('permiso');
			$table->unique(array('id_usuario', 'permiso'));
		});
		
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down(){
		Schema::drop('permisos_usuario');
		Schema::drop('usuarios');
	}

}
