<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
class UsuarioEmpresa extends Model {
	protected $table = 'usuarios_empresa';
	public $timestamps = false;
}
