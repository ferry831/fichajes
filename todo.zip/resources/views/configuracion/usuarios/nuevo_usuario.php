<div class="modal fade" id="nuevoUsuario" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form class="form-horizontal" role="form" method="post" action="<?=\URL::action('Configuracion\Usuarios@postNuevoUsuario')?>" onsubmit="return validar_nuevo_usuario(this)">
        <div class="modal-header">
          <h4 class="modal-title"><?=trans('configuracion.nuevo_usuario')?></h4>
        </div>
        <div class="modal-body">
          <input type="hidden" name="_token" value="<?=csrf_token()?>">
          <?

            $inline = true;

            $nombre = 'nombre';
            $label = trans('configuracion.nombre');
            $requerido = true;
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

            $nombre = 'apellidos';
            $label = trans('configuracion.apellidos');
            echo view('ui/input', compact('nombre', 'label', 'inline'));

            $nombre = 'email';
            $label = trans('configuracion.email');
            $validar = 'email';
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido', 'validar'));

            $nombre = 'password';
            $label = trans('configuracion.password');
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

            /*
            $perfiles = \Config::get('perfiles');
            if(count($perfiles) > 0){
              $nombre = 'perfil';
              $label = trans('configuracion.perfil');
              $opciones = array();
              foreach($perfiles as $perfil){
                $opciones[] = array('label' => trans('perfiles.'.$perfil), 'valor' => $perfil);
              }
              echo view('ui/select', compact('nombre', 'label', 'inline', 'requerido', 'opciones'));
            }
            */

          ?>
          <input type="hidden" name="perfil" value="administrador">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal"><?=trans('base.cerrar')?></button>
          <?=view('ui/submit', ['label' => trans('configuracion.crear_usuario')])?>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  function validar_nuevo_usuario(f){
    if(f.password.value.trim() == ''){ swal('<?=trans('base.error')?>', '<?=trans('configuracion.password_vacio')?>', 'error'); return false; }
    if(f.password.value.trim().length < 5 ){ swal('<?=trans('base.error')?>', '<?=trans('configuracion.password_corto')?>', 'error'); return false; }
    return true;
  }
</script>
