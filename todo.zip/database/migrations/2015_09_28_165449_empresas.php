<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Empresas extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up(){

		Schema::create('empresas', function(Blueprint $table){
			$table->bigIncrements('id');
			$table->string('razon_social')->unique();
			$table->string('cif')->unique();
			$table->string('centro_trabajo');
			$table->string('ccc');
			$table->string('pin', 4);
			$table->timestamps();
		});

		Schema::create('usuarios_empresa', function(Blueprint $table){
			$table->bigInteger('id_usuario')->unsigned()->index();
			$table->foreign('id_usuario')->references('id')->on('usuarios')->onDelete('cascade');
			$table->bigInteger('id_empresa')->unsigned()->index();
			$table->foreign('id_empresa')->references('id')->on('empresas')->onDelete('cascade');
		});

	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down(){
		Schema::drop('usuarios_empresa');
		Schema::drop('empresas');
	}

}
