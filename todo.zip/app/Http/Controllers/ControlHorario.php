<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;

class ControlHorario extends Controller {

	public static $perfiles = [];
	public static $permisos = [];

	private function comprobarSesion(){

		$id_empresa = \Session::get('id_empresa', 0);
		if($id_empresa > 0){
			try {
				$empresa = \App\Models\Empresa::findOrFail($id_empresa);
			} catch(\Exception $e){
				$id_empresa = 0;
			}
		}
		\Session::put('id_empresa', $id_empresa);

		if($id_empresa > 0){
			$id_trabajador = \Session::get('id_trabajador', 0);
			if($id_trabajador > 0){
				try {
					$trabajador = \App\Models\Trabajador::findOrFail($id_trabajador);
					if($trabajador->id_empresa != $empresa->id) $id_trabajador = 0;
				} catch(\Exception $e){
					$id_trabajador = 0;
				}
			}
		} else {
			$id_trabajador = 0;
		}
		\Session::put('id_trabajador', $id_trabajador);

	}

	public function getIndex(){

		if(\Input::has('t')){
			$empresa = \App\Models\Empresa::where('token_autologin', \Input::get('t'))->first();
			if(!is_null($empresa)) \Session::put('id_empresa', $empresa->id);
			return \Redirect::action('ControlHorario@getIndex');
		}

		$this->comprobarSesion();
		$id_empresa = \Session::get('id_empresa', 0);
		if($id_empresa > 0) $empresa = \App\Models\Empresa::findOrFail($id_empresa); else $empresa = null;
		$id_trabajador = \Session::get('id_trabajador', 0);
		if($id_trabajador > 0) $trabajador = \App\Models\Trabajador::findOrFail($id_trabajador); else $trabajador = null;

		if($id_empresa == 0){
			$params = ['contenido' => view('control_horario/login_empresa')];
		} elseif($id_trabajador == 0){
			$params = ['contenido' => view('control_horario/login_trabajador', compact('empresa'))];
		} else {
			$params = ['contenido' => view('control_horario/fichaje', compact('empresa', 'trabajador'))];
		}

		return view('plantilla_control_horario', $params);

	}

	public function getAlias($alias){

		$alias = trim($alias);
		if($alias == ''){
			\Session::flush();
			\Session::put('error', trans('base.alias_desconocido'));
			return \Redirect::action('ControlHorario@getIndex');
		}

		$empresa = \App\Models\Empresa::where('alias_autologin', $alias)->first();
		if(!is_null($empresa)) \Session::put('id_empresa', $empresa->id);
		return \Redirect::action('ControlHorario@getIndex');

	}

	public function postLoginEmpresa(){
		$sql = 'select id from empresas where cif=? and pin=?';
		$empresas = \DB::select($sql, [\Input::get('cif'), \Input::get('pin')]);
		if(count($empresas) == 0){
			\Session::put('error', trans('base.acceso_denegado_empresa'));
		} else {
			\Session::put('id_empresa', $empresas[0]->id);
		}
		return \Redirect::action('ControlHorario@getIndex');
	}

	public function postLoginTrabajador(){
		$sql = 'select id from trabajadores where id_empresa=? and nif=? and pin=?';
		$trabajadores = \DB::select($sql, [\Session::get('id_empresa', 0), \Input::get('nif'), \Input::get('pin')]);
		if(count($trabajadores) == 0){
			\Session::put('error', trans('base.acceso_denegado_trabajador'));
		} else {
			\Session::put('id_trabajador', $trabajadores[0]->id);
		}
		return \Redirect::action('ControlHorario@getIndex');
	}

	public function postIniciarTurno(){

		$this->comprobarSesion();
		$id_empresa = \Session::get('id_empresa', 0);
		$id_trabajador = \Session::get('id_trabajador', 0);

		$sql = 'select id from fichajes where id_trabajador=? and fin is null order by id desc limit 0, 1';
		$fichajes = \DB::select($sql, [$id_trabajador]);

		if($id_empresa > 0 && $id_trabajador > 0 && count($fichajes) == 0){
			$fichaje = new \App\Models\Fichaje;
			$fichaje->id_trabajador = $id_trabajador;
			$fichaje->inicio = date('Y-m-d G:i:s');
			$fichaje->save();
		}

		return redirect()->back();

	}

	public function postFinalizarTurno(){

		$this->comprobarSesion();
		$id_empresa = \Session::get('id_empresa', 0);
		$id_trabajador = \Session::get('id_trabajador', 0);

		$sql = 'select id from fichajes where id_trabajador=? and fin is null order by id desc limit 0, 1';
		$fichajes = \DB::select($sql, [$id_trabajador]);

		if($id_empresa > 0 && $id_trabajador > 0 && count($fichajes) == 1){
			$fichaje = \App\Models\Fichaje::findOrFail($fichajes[0]->id);
			$fichaje->fin = date('Y-m-d G:i:s');
			$fichaje->save();
		}

		return redirect()->back();

	}

	public function getCerrarSesion(){
		\Session::forget('id_trabajador');
		return redirect()->back();
	}

	public function getCerrarSesionEmpresa(){
		\Session::forget('id_empresa');
		return redirect()->back();
	}

}
