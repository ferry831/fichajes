<? if(!isset($perfil_empresa)) $perfil_empresa = false; ?>

<div class="block-header">
  <h2><?=trans('base.ficha_empresa')?></h2>
  <? if(!$perfil_empresa){ ?>
  <div class="actions">
    <button class="btn btn-default waves-effect" onclick="document.location.href='<?=\URL::action('Empresas@getIndex')?>'"><?=trans('base.listado_empresas')?></button>
    <button class="btn btn-danger waves-effect" onclick="eliminar()"><?=trans('base.borrar_empresa')?></button>
    <button class="btn btn-primary waves-effect" data-toggle="modal" href="#nuevaEmpresa"><?=trans('base.nueva_empresa')?></button>
  </div>
  <? } ?>
</div>

<? if(!$perfil_empresa) echo view('empresas/nueva_empresa'); ?>
<?=view('empresas/nuevo_usuario', compact('empresa', 'perfil_empresa'))?>
<?=view('empresas/editar_usuario', compact('empresa', 'perfil_empresa'))?>

<? if(!$perfil_empresa){ ?>
<script>
  function eliminar(){
    swal({
      title: "<?=trans('base.estas_seguro')?>",
      text: "<?=trans('base.no_undo')?>",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#DD6B55",
      confirmButtonText: "<?=trans('base.si')?>",
      cancelButtonText: "<?=trans('base.no')?>",
      closeOnConfirm: false
    }, function(){
      $.post(
        '<?=\URL::action('Empresas@postEliminar')?>',
        {id: <?=$empresa->id?>, _token: '<?=csrf_token()?>'},
        function(r){
          if(r != "") swal("<?=trans('base.error')?>", r, "error");
          else document.location.href = '<?=\URL::action('Empresas@getIndex')?>';
        }
      );
    });
  }
</script>
<? } ?>

<div class="col-sm-6">

  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('base.datos_empresa')?></h2>
    </div>
    <div class="card-body card-padding">
      <form id="datos_empresa" name="datos_empresa" method="POST" ajax="true" action="<?=(!$perfil_empresa)?\URL::action('Empresas@postInfo'):\URL::action('Empresa@postIndex')?>">

        <input type="hidden" name="id" value="<?=$empresa->id?>">
        <input type="hidden" name="operacion" value="datos_empresa">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">

        <?

          $nombre = 'razon_social';
          $label = trans('base.razon_social');
          $valor = $empresa->razon_social;
          $requerido = true;
          $readonly = $perfil_empresa;
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido', 'readonly'));

          $nombre = 'cif';
          $label = trans('base.cif');
          $valor = $empresa->cif;
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido', 'readonly'));

          $nombre = 'centro_trabajo';
          $label = trans('base.centro_trabajo');
          $valor = $empresa->centro_trabajo;
          echo view('ui/input', compact('nombre', 'label', 'valor'));

          $nombre = 'hora_cierre';
          $label = trans('base.hora_cierre_defecto');
          $valor = $empresa->hora_cierre;
          $validar = 'hora';
          $requerido = true;
          echo view('ui/input', compact('nombre', 'label', 'valor', 'validar', 'requerido'));

					$nombre = 'ccc';
          $label = trans('base.ccc');
          $valor = $empresa->ccc;
          echo view('ui/input', compact('nombre', 'label', 'valor'));

          echo view('ui/submit');

        ?>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('base.logo')?></h2>
    </div>
    <div class="card-body card-padding">
      <form id="form_logo" name="form_logo" method="POST" action="<?=(!$perfil_empresa)?\URL::action('Empresas@postInfo'):\URL::action('Empresa@postIndex')?>" onsubmit="return validar_logo(this)" enctype="multipart/form-data">

        <input type="hidden" name="id" value="<?=$empresa->id?>">
        <input type="hidden" name="operacion" value="guardar_logo">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">

        <? if($empresa->logo != '' && file_exists(public_path('logo/'.$empresa->logo))){ ?>
        <img src="<?=asset('logo/'.$empresa->logo)?>" style="margin-bottom: 15px; width: 100%;">
        <? }?>

        <?

          $id = 'logo';
          $nombre = 'logo';
          $tipo = 'file';
          $requerido = true;
          echo view('ui/input', compact('id', 'nombre', 'tipo', 'requerido'));

          echo view('ui/submit');

          if($empresa->logo != ''){
            ?><button type="button" class="btn btn-danger waves-effect eliminar_logo"><?=trans('base.borrar_logo')?></button><?
          }

        ?>

      </form>
      <form id="eliminar_logo" name="eliminar_logo" method="POST" action="<?=(!$perfil_empresa)?\URL::action('Empresas@postInfo'):\URL::action('Empresa@postIndex')?>">
        <input type="hidden" name="id" value="<?=$empresa->id?>">
        <input type="hidden" name="operacion" value="eliminar_logo">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">
        </form>
    </div>
  </div>

  <script>
    function validar_logo(form){
      var logo = form.logo.value;
      if(logo == ''){
        swal('<?=trans('base.error')?>', '<?=trans('base.falta_logo')?>', 'error'); return false;
        return false;
      }
      return true;
    }
    $(document).ready(function(){
      $('button.eliminar_logo').click(function(){
        document.eliminar_logo.submit();
      })
    });
  </script>

</div>

<div class="col-sm-6">

  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('base.pin_acceso')?></h2>
    </div>
    <div class="card-body card-padding">
      <form id="pin_acceso" name="pin_acceso" method="POST" ajax="true" action="<?=(!$perfil_empresa)?\URL::action('Empresas@postInfo'):\URL::action('Empresa@postIndex')?>" onsubmit="return validar_pin(this)">

        <input type="hidden" name="id" value="<?=$empresa->id?>">
        <input type="hidden" name="operacion" value="pin_acceso">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">

        <?

          $nombre = 'pin';
          $label = trans('base.pin');
          $valor = $empresa->pin;
          $requerido = true;
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido'));

          echo view('ui/submit');

        ?>

      </form>

      <script>
        function validar_pin(f){
          var pin = f.pin.value.trim();
          var regEx = /^[0-9]{4}$/i;
        	if(pin.search(regEx) == -1){
            swal('<?=trans('base.error')?>', '<?=trans('base.pin_incorrecto')?>', 'error'); return false;
            return false;
          }
        	else return true;
        }
      </script>

    </div>
  </div>

	<div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('base.url_fichajes')?></h2>
    </div>
    <div class="card-body card-padding">
      <form id="regenerar_token_autologin" name="regenerar_token_autologin" method="POST" action="<?=(!$perfil_empresa)?\URL::action('Empresas@postInfo'):\URL::action('Empresa@postIndex')?>">

        <input type="hidden" name="id" value="<?=$empresa->id?>">
        <input type="hidden" name="operacion" value="regenerar_token_autologin">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">

        <?

          $nombre = 'token_autologin';
          $valor = \URL::action('ControlHorario@getIndex').'?t='.$empresa->token_autologin;
					$readonly = true;
          echo view('ui/input', compact('nombre', 'valor', 'readonly'));

					$label = trans('base.regenerar_url');
          echo view('ui/submit', compact('label'));

        ?>

      </form>

    </div>
  </div>

  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('base.url_fichajes_corta')?></h2>
    </div>
    <div class="card-body card-padding">
      <form id="form_alias_autologin" name="form_alias_autologin" method="POST" action="<?=(!$perfil_empresa) ? \URL::action('Empresas@postInfo') : \URL::action('Empresa@postIndex')?>">

        <input type="hidden" name="id" value="<?=$empresa->id?>">
        <input type="hidden" name="operacion" value="guardar_alias_autologin">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">

        <?

          $nombre = 'alias_autologin';
          $valor = !is_null($empresa->alias_autologin) ? $empresa->alias_autologin : '';
          $readonly = false;
          $label = trans('base.alias');
          echo view('ui/input', compact('nombre', 'valor', 'readonly', 'label'));

          if(!is_null($empresa->alias_autologin)){
            $nombre = 'url_alias_autologin';
            $valor = \URL::action('ControlHorario@getAlias', ['alias' => $empresa->alias_autologin]);
            $readonly = true;
            $label = trans('base.url_generada');
            echo view('ui/input', compact('nombre', 'valor', 'readonly', 'label'));
          }

					$label = trans('base.guardar');
          echo view('ui/submit', compact('label'));

        ?>

      </form>

    </div>
  </div>

	<div class="card">
    <div class="card-header bgm-bluegray">
      <h2>
        <?=trans('base.listado_usuarios')?>
        <ul class="actions">
          <li><a data-toggle="modal" href="#nuevoUsuarioEmpresa"><i class="md md-add c-white"></i></a></li>
        </ul>
      </h2>
    </div>
    <div class="card-body table-responsive m-t-15">
      <?
        $sql = "select u.id, u.nombre, u.apellidos, u.email from usuarios u left join usuarios_empresa ue on u.id=ue.id_usuario where ue.id_empresa=? order by nombre, apellidos, email";
        $usuarios = \DB::select($sql, [$empresa->id]);
        if(count($usuarios) > 0){
      ?>
      <table class="table table-condensed">
        <thead>
          <tr>
            <th><?=trans('base.nombre')?></th>
            <th><?=trans('base.apellidos')?></th>
            <th><?=trans('base.email')?></th>
            <th class="botones">&nbsp;</th>
          </tr>
        </thead>
        <tbody>
          <? foreach($usuarios as $usuario){ ?>
          <tr>
            <td><?=$usuario->nombre?></td>
            <td><?=$usuario->apellidos?></td>
            <td><?=$usuario->email?></td>
            <td class="p-r-15 text-right">
              <button class="btn btn-danger btn-xs waves-effect" onclick="eliminar_usuario(<?=$usuario->id?>)"><i class="md md-clear"></i></button>
              <button class="btn btn-primary btn-xs waves-effect" onclick="editar_usuario(<?=htmlentities(json_encode($usuario))?>)"><i class="md md-edit"></i></button>
              <?
                $usuario = \App\Models\Usuario::find($usuario->id);
                if($usuario->puede('inicio_sesion')){
              ?>
              <button class="btn bgm-green btn-xs waves-effect" onclick="activar_usuario(<?=$usuario->id?>)"><i class="md md-lock-open"></i></button>
              <? } else { ?>
              <button class="btn btn-danger btn-xs waves-effect" onclick="activar_usuario(<?=$usuario->id?>)"><i class="md md-lock-outline"></i></button>
              <? } ?>
            </td>
          </tr>
          <? } ?>
        </tbody>
      </table>
      <? } else { ?>
      <p class="p-t-25 p-b-25 text-center"><?=trans('base.no_hay_usuarios')?></p>
      <? } ?>
    </div>
  </div>

  <script>
    function editar_usuario(usuario){
      $('#editarUsuarioEmpresa input[name="id_usuario"]').val(usuario.id);
      $('#editarUsuarioEmpresa input[name="nombre"]').val(usuario.nombre);
      $('#editarUsuarioEmpresa input[name="apellidos"]').val(usuario.apellidos);
      $('#editarUsuarioEmpresa input[name="email"]').val(usuario.email);
      $('#editarUsuarioEmpresa').modal('show');
    }
    function activar_usuario(id){
      $.post(
        '<?=(!$perfil_empresa)?\URL::action('Empresas@postActivarUsuario'):\URL::action('Empresa@postActivarUsuario')?>',
        {id_empresa: <?=$empresa->id?>, id_usuario: id, _token: '<?=csrf_token()?>'},
        function(r){
          if(r != "") swal("<?=trans('base.error')?>", r, "error");
          else document.location.href = document.location.href;
        }
      );
    }
    function eliminar_usuario(id){
      swal({
        title: "<?=trans('base.estas_seguro')?>",
        text: "<?=trans('base.no_undo')?>",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "<?=trans('base.si')?>",
        cancelButtonText: "<?=trans('base.no')?>",
        closeOnConfirm: false
      }, function(){
        $.post(
          '<?=(!$perfil_empresa)?\URL::action('Empresas@postEliminarUsuario'):\URL::action('Empresa@postEliminarUsuario')?>',
          {id_empresa: <?=$empresa->id?>, id_usuario: id, _token: '<?=csrf_token()?>'},
          function(r){
            if(r != "") swal("<?=trans('base.error')?>", r, "error");
            else document.location.href = document.location.href;
          }
        );
      });
    }
  </script>

  <!--
  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('base.avisos_fichajes')?></h2>
    </div>
    <div class="card-body card-padding p-t-10">
      <form id="avisos_fichajes" name="avisos_fichajes" method="POST" ajax="true" action="<?=(!$perfil_empresa)?\URL::action('Empresas@postInfo'):\URL::action('Empresa@postIndex')?>" onsubmit="return validar_avisos_fichajes(this)">

        <input type="hidden" name="id" value="<?=$empresa->id?>">
        <input type="hidden" name="operacion" value="avisos_fichajes">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">

        <?
          $avisos = json_decode($empresa->avisos_turno_no_iniciado, true);
          if(is_null($avisos) || !is_array($avisos)) $avisos = ['lunes' => null, 'martes' => null, 'miercoles' => null, 'jueves' => null, 'viernes' => null, 'sabado' => null, 'domingo' => null];
        ?>

        <div class="p-t-10">
          <? $i=0; foreach(['lunes', 'viernes', 'martes', 'sabado', 'miercoles', 'domingo', 'jueves'] as $dia){ $i++; ?>
          <div class="col-xs-2 p-t-10 p-r-0 p-l-0">
            <p class="text-right m-b-0"><?=trans('base.'.$dia)?></p>
          </div>
          <div class="col-xs-1">
            <div class="checkbox <? if($dia == 'jueves') echo 'm-b-20'; ?>">
              <label class="" for="aviso_<?=$dia?>">
                <input type="checkbox" id="aviso_<?=$dia?>" value="si" name="aviso_<?=$dia?>" class="checkbox_aviso" <? if(!is_null($avisos[$dia])) echo 'checked="checked"'; ?>>
                <i class="input-helper"></i>
              </label>
              <div class="clearfix"></div>
            </div>
          </div>
          <div class="col-xs-3">
            <div class="form-group m-b-10">
              <div class="fg-line">
                <input id="hora_aviso_<?=$dia?>" type="text" class="form-control input-sm input-mask" data-mask="00:00" name="hora_aviso_<?=$dia?>" placeholder="hh:mm" <? if(!is_null($avisos[$dia])) echo 'value="'.$avisos[$dia].'"'; ?>>
              </div>
            </div>
          </div>
          <? if($i%2 == 0){ ?><div class="clearfix"></div><? }} ?>
          <div class="clearfix"></div>
        </div>

        <script>

          $(document).ready(function(){
            $('.checkbox_aviso').change(function(){
              if(!this.checked){
                $('#hora_' + this.name).val('');
                $('#hora_' + this.name).prop('readonly', true);
              } else {
                $('#hora_' + this.name).prop('readonly', false);
              }
            });
            $('.checkbox_aviso').trigger('change');
          });

          function validar_avisos_fichajes(f){
            <? foreach(['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo'] as $dia){ ?>
            if(f.aviso_<?=$dia?>.checked){
              if(f.hora_aviso_<?=$dia?>.value.trim() == ''){ ui_error_validacion('<?=trans('base.hora_dia_vacio', ['dia' => trans('base.'.$dia)])?>'); return false; }
              if(!validar_hora(f.hora_aviso_<?=$dia?>.value.trim())){ ui_error_validacion('<?=trans('base.hora_dia_invalida', ['dia' => trans('base.'.$dia)])?>'); return false; }
            }
            <? } ?>
            return true;
          }

        </script>

        <? echo view('ui/submit'); ?>

      </form>
    </div>
  </div>
  -->

</div>
