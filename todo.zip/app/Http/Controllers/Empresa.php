<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;

class Empresa extends Controller {

	public static $perfiles = ['empresa'];
	public static $permisos = [];

	public function getIndex(){

		$usuario = \Auth::user();
		$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
		$empresa = \DB::select($sql, [$usuario->id]);

		if(count($empresa) == 0) return \Redirect::action('Login@getLogout');
		$empresa = \App\Models\Empresa::find($empresa[0]->id_empresa);
		if(is_null($empresa)) return \Redirect::action('Login@getLogout');

		$perfil_empresa = true;

		$params = [
			'menu' => 'empresas',
			'submenu' => '',
			'contenido' => view('empresas/info', compact('empresa', 'perfil_empresa')),
		];
		return view('plantilla', $params);

	}

	public function postIndex(){
		$salida = '';
		try {

			$usuario = \Auth::user();
			$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
			$empresa = \DB::select($sql, [$usuario->id]);
			$empresa = \App\Models\Empresa::findOrFail($empresa[0]->id_empresa);

			switch(\Input::get('operacion')){

				case 'datos_empresa':
					$empresa->hora_cierre = \Input::get('hora_cierre');
					$empresa->centro_trabajo = \Input::get('centro_trabajo');
					$empresa->ccc = \Input::get('ccc');
					$empresa->save();
				break;

				case 'pin_acceso':
					$empresa->pin = \Input::get('pin');
					$empresa->save();
				break;

				case 'avisos_fichajes':
					$avisos = ['lunes' => null, 'martes' => null, 'miercoles' => null, 'jueves' => null, 'viernes' => null, 'sabado' => null, 'domingo' => null];
					foreach($avisos as $dia => $valor){
						if(\Input::has('hora_aviso_'.$dia)){
							$avisos[$dia] = \Input::get('hora_aviso_'.$dia);
						}
					}
					$empresa->avisos_turno_no_iniciado = json_encode($avisos);
					$empresa->save();
				break;

				case 'regenerar_token_autologin':
					$empresa->token_autologin = \App\Models\Empresa::generarTokenAutologin();
					$empresa->save();
					\Session::put('info', trans('base.url_regenerada'));
					return redirect()->back();
				break;

				case 'guardar_alias_autologin':

					$alias = trim(\Input::get('alias_autologin'));
					
					if($alias == ''){

						$empresa->alias_autologin = null;
						$empresa->save();
						\Session::put('info', trans('base.cambios_guardados'));
						return redirect()->back();

					} else {

						if(!ctype_alnum($alias)){
							\Session::put('error', trans('base.alias_no_valido'));
							return redirect()->back();
						}

						$duplicado = \App\Models\Empresa::where('id', '<>', $empresa->id)->where('alias_autologin', $alias)->first();
						if(!is_null($duplicado)){
							
							\Session::put('error', trans('base.alias_duplicado'));
							return redirect()->back();
							
						} else {
							
							$empresa->alias_autologin = $alias;
							$empresa->save();
							\Session::put('info', trans('base.cambios_guardados'));
							return redirect()->back();

						}

					}
					
				break;

				case 'guardar_logo':

					$validator = \Validator::make(\Input::all(), [
						'logo' => 'required|image|max:2048'
					]);

					if ($validator->fails()){
						\Session::put('error', trans('base.imagen_no_valida'));
						return redirect()->back();
					}

					do {
						$nombre = uniqid().'.png';
					} while(\App\Models\Empresa::where('logo', $nombre)->count() > 0);

					if($empresa->logo != '' && file_exists(public_path('logo/'.$empresa->logo))){
						unlink(public_path('logo/'.$empresa->logo));
					}

					$empresa->logo = $nombre;
					$empresa->save();

					\Image::make(\Input::file('logo'))->save(public_path('logo/'.$empresa->logo));

					\Session::put('info', trans('base.cambios_guardados'));
					return redirect()->back();

				break;

				case 'eliminar_logo':

					if($empresa->logo != '' && file_exists(public_path('logo/'.$empresa->logo))){
						unlink(public_path('logo/'.$empresa->logo));
					}

					$empresa->logo = '';
					$empresa->save();

					\Session::put('info', trans('base.cambios_guardados'));
					return redirect()->back();

				break;

			}

		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.empresa_desconocida');
		} catch(\Illuminate\Database\QueryException $e){
			$salida = trans('base.empresa_duplicada');
		} catch(\Exception $e){
			$salida = trans('base.empresa_desconocida');
		} catch(\Exception $ex){
			$salida = trans('base.error_inesperado').$ex->getMessage();
		}
		return \Response::json($salida);
	}

	public function postNuevoUsuario(){
		try {
			$usuario = \Auth::user();
			$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
			$empresa = \DB::select($sql, [$usuario->id]);
			$empresa = \App\Models\Empresa::findOrFail($empresa[0]->id_empresa);
		} catch(\Exception $e){
			\Session::put('error', trans('base.empresa_desconocida'));
			return redirect()->back();
		}
		try {
			$usuario = new \App\Models\Usuario;
			$usuario->nombre = \Input::get('nombre');
			$usuario->apellidos = \Input::get('apellidos');
			$usuario->email = \Input::get('email');
			$usuario->password = bcrypt(\Input::get('password'));
			$usuario->perfil = 'empresa';
			$usuario->save();
			$usuario_empresa = new \App\Models\UsuarioEmpresa;
			$usuario_empresa->id_usuario = $usuario->id;
			$usuario_empresa->id_empresa = $empresa->id;
			$usuario_empresa->save();
			$usuario->setPermiso('inicio_sesion');
		} catch(\Illuminate\Database\QueryException $e){
			\Session::put('error', trans('base.usuario_existe'));
			return redirect()->back();
		}
		return redirect()->back();
	}

	public function postActivarUsuario(){
		$salida = '';
		try {
			$usuario = \Auth::user();
			$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
			$empresa = \DB::select($sql, [$usuario->id]);
			$empresa = \App\Models\Empresa::findOrFail($empresa[0]->id_empresa);
		} catch(\Exception $e){
			$salida = trans('base.empresa_desconocida');
			return \Response::json($salida);
		}
		try {
			$usuario = \App\Models\Usuario::findOrFail(\Input::get('id_usuario'));
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.usuario_desconocido');
			return \Response::json($salida);
		}
		if($salida == ''){
			if(\App\Models\UsuarioEmpresa::whereRaw('id_usuario=? and id_empresa=?', [$usuario->id, $empresa->id])->count() == 0){
				$salida = trans('base.usuario_desconocido');
			} else {
				if($usuario->puede('inicio_sesion')){
					$usuario->unsetPermiso('inicio_sesion');
					\Session::put('info', trans('base.usuario_bloqueado'));
				} else {
					$usuario->setPermiso('inicio_sesion');
					\Session::put('info', trans('base.usuario_activado'));
				}
			}
		}
		return \Response::json($salida);
	}

	public function postEliminarUsuario(){
		$salida = '';
		try {
			$usuario = \Auth::user();
			$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
			$empresa = \DB::select($sql, [$usuario->id]);
			$empresa = \App\Models\Empresa::findOrFail($empresa[0]->id_empresa);
		} catch(\Exception $e){
			$salida = trans('base.empresa_desconocida');
			return \Response::json($salida);
		}
		try {
			$usuario = \App\Models\Usuario::findOrFail(\Input::get('id_usuario'));
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.usuario_desconocido');
			return \Response::json($salida);
		}
		if($salida == ''){
			if(\App\Models\UsuarioEmpresa::whereRaw('id_usuario=? and id_empresa=?', [$usuario->id, $empresa->id])->count() == 0){
				$salida = trans('base.usuario_desconocido');
			} else {
				$usuario->delete();
				\Session::put('info', trans('base.usuario_eliminado'));
			}
		}
		return \Response::json($salida);
	}

	public function postInfoUsuario(){
		$salida = '';
		try {
			$usuario = \Auth::user();
			$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
			$empresa = \DB::select($sql, [$usuario->id]);
			$empresa = \App\Models\Empresa::findOrFail($empresa[0]->id_empresa);
		} catch(\Exception $e){
			\Session::put('error', trans('base.empresa_desconocida'));
			return redirect()->back();
		}
		try {
			$usuario = \App\Models\Usuario::findOrFail(\Input::get('id_usuario'));
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			\Session::put('error', trans('base.usuario_desconocido'));
			return redirect()->back();
		}
		if(\App\Models\UsuarioEmpresa::whereRaw('id_usuario=? and id_empresa=?', [$usuario->id, $empresa->id])->count() == 0){
			\Session::put('error', trans('base.usuario_desconocido'));
			return redirect()->back();
		}
		try {
			$usuario->nombre = \Input::get('nombre');
			$usuario->apellidos = \Input::get('apellidos');
			$usuario->email = \Input::get('email');
			if(\Input::has('password') && trim(\Input::get('password')) != '') $usuario->password = bcrypt(\Input::get('password'));
			$usuario->save();
			\Session::put('info', trans('base.usuario_modificado'));
		} catch (\Illuminate\Database\QueryException $e){
			\Session::put('error', trans('base.usuario_existe'));
		}
		return redirect()->back();
	}

}
