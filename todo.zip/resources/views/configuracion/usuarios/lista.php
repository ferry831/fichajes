<div class="block-header">
  <h2><?=trans('base.gestion_usuarios')?></h2>
  <div class="actions">
    <button class="btn btn-primary waves-effect" data-toggle="modal" href="#nuevoUsuario"><?=trans('configuracion.nuevo_usuario')?></button>
  </div>
</div>
<?=view('configuracion/usuarios/nuevo_usuario')?>

<?php

  // datatable

	$id = 'listado_usuarios';
	$titulo = trans('configuracion.listado_usuarios');
	$url = \URL::action('Configuracion\Usuarios@postListadoUsuarios');
  $columnas = [
    ['id' => 'id', 'label' => '', 'visible' => false, 'identifier' => true],
    ['id' => 'nombre', 'label' => trans('configuracion.nombre'), 'visible' => true, 'sortable' => true, 'searchable' => true, 'order' => 'asc'],
    ['id' => 'apellidos', 'label' => trans('configuracion.apellidos'), 'visible' => true, 'sortable' => true, 'searchable' => true],
    ['id' => 'email', 'label' => trans('configuracion.email'), 'visible' => true, 'sortable' => true, 'searchable' => true],
    /*['id' => 'perfil', 'label' => trans('configuracion.perfil'), 'formatter' => 'perfiles', 'visible' => true, 'sortable' => false, 'searchable' => false],*/
    ['id' => 'botones', 'label' => '', 'visible' => true, 'formatter' => 'botones', 'align' => 'right'],
  ];
  $selector = false;

  $usuario = Auth::user();
  ob_start(); ?>
    var botones = '';
    if(row.id != <?=$usuario->id?>) botones += '<button class="btn btn-danger btn-xs waves-effect" data-row-id="' + row.id + '" onclick="eliminar(' + row.id + ')"><i class="md md-delete"></i> <?=trans('base.borrar')?></button> ';
    botones += '<button class="btn btn-primary btn-xs waves-effect" data-row-id="' + row.id + '" onclick="info_usuario(' + row.id + ')"><i class="md md-info"></i> <?=trans('base.info')?></button> ';
    return botones.trim();
  <? $botones = ob_get_clean();

  ob_start();
    $perfiles = \Lang::get('perfiles');
    ?> switch(row.perfil){ <?
    foreach($perfiles as $perfil => $label){
      ?>case '<?=$perfil?>': return <?=json_encode($label)?>; break; <?
    }
    ?> } return '';
  <? $perfiles = ob_get_clean();

  $formatters = compact('botones', 'perfiles');

  echo view('ui/datatable', compact('id', 'titulo', 'url', 'columnas', 'selector', 'formatters'));

?>

<script>

  function info_usuario(id){
    document.location.href = '<?=\URL::action('Configuracion\Usuarios@getInfo')?>/' + id;
  }

  function eliminar(id){
    swal({
      title: "<?=trans('base.estas_seguro')?>",
      text: "<?=trans('base.no_undo')?>",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#DD6B55",
      confirmButtonText: "<?=trans('base.si')?>",
      cancelButtonText: "<?=trans('base.no')?>",
      closeOnConfirm: false
    }, function(){
      $.post(
        '<?=\URL::action('Configuracion\Usuarios@postEliminar')?>',
        {id: id, _token: '<?=csrf_token()?>'},
        function(r){
          if(r != "") swal("<?=trans('base.error')?>", r, "error");
          else {
            $("#listado_usuarios").bootgrid("reload");
            swal.close();
            info('<?=trans('configuracion.usuario_eliminado')?>', '<?=trans('base.cerrar')?>');
          }
        }
      );
    });
  }

</script>
