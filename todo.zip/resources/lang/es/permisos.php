<?php

	return array(

		'sin_permiso' => 'No tienes permiso para realizar esa acción...',

		'basicos' => 'Básicos',
		'inicio_sesion' => 'Iniciar sesión',
		'admin' => 'Administrador (todos los permisos)',

		'configuracion' => 'Configuración',
		'gestion_usuarios' => 'Gestión de usuarios',

		// perfil administrador

		'gestion_administradores' => 'Gestión de administradores',

	);
