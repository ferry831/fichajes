<?php

namespace App\Http\Controllers\Configuracion;
use App\Http\Controllers\Controller;

class Usuarios extends Controller {

	public static $perfiles = ['administrador'];
	public static $permisos = ['gestion_usuarios'];

	public function getIndex(){

		$params = [
			'menu' => 'configuracion',
			'submenu' => 'usuarios',
			'contenido' => view('configuracion/usuarios/lista'),
		];
		return view('plantilla', $params);

	}

	public function postListadoUsuarios(){

		$output = new \stdClass();
		$output->current = \Input::get('current');
		$output->rowCount = \Input::get('rowCount');
		$output->rows = array();
		$output->total = 0;

		$sql = 'select count(*) as c from usuarios where perfil=?';
		$params = array('administrador');

		$res = \DB::select($sql);
		if(isset($res[0]->c)) $output->total = $res[0]->c;

		if(trim(\Input::get('searchPhrase')) != ''){
			$sql .= ' and (email like ? or nombre like ? or apellidos like ?)';
			$params[] = '%'.trim(\Input::get('searchPhrase')).'%';
			$params[] = '%'.trim(\Input::get('searchPhrase')).'%';
			$params[] = '%'.trim(\Input::get('searchPhrase')).'%';
		}

		$sort = \Input::get('sort');
		if(count($sort) > 0){
			$orden = array();
			foreach($sort as $id => $direccion){
				switch($id){
					case 'nombre': $orden[] = 'nombre '.$direccion; break;
					case 'apellidos': $orden[] = 'apellidos '.$direccion; break;
					case 'email': $orden[] = 'email '.$direccion; break;
				}
			}
			$sql .= ' order by '.implode(', ', $orden);
		}

		$sql = str_replace('count(*) as c', 'id, email, nombre, apellidos, perfil', $sql);
		if(\Input::get('rowCount') > 0) $sql .= ' limit '.((\Input::get('current') - 1) * \Input::get('rowCount')).', '.(\Input::get('rowCount'));

		$resultados = \DB::select($sql, $params);
		if(count($resultados) > 0){
			foreach($resultados as $r){
				$r->botones = '';
				$output->rows[] = $r;
			}
		}

		return \Response::json($output);

	}

	public function postNuevoUsuario(){

		try {
			$usuario = \App\Models\Usuario::where('email', '=', \Input::get('email'))->firstOrFail();
			\Session::put('error', trans('configuracion.usuario_existe'));
			return \Redirect::action('Configuracion\Usuarios@getIndex');
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){

			$usuario = new \App\Models\Usuario;
			$usuario->email = \Input::get('email');
			$usuario->password = bcrypt(\Input::get('password'));
			$usuario->nombre = \Input::get('nombre');
			$usuario->apellidos = \Input::get('apellidos');
			if(\Input::has('perfil')) $usuario->perfil = \Input::get('perfil');
			$usuario->save();

			\Session::put('info', trans('configuracion.usuario_creado'));
			return \Redirect::action('Configuracion\Usuarios@getInfo', [$usuario->id]);
		}

		\Session::put('error', trans('configuracion.error_creando_usuario'));
		return \Redirect::action('Configuracion\Usuarios@getIndex');

	}

	public function getInfo($id = 0){
		try {
			$usuario = \App\Models\Usuario::findOrFail($id);
			$params = [
				'menu' => 'configuracion',
				'submenu' => 'usuarios',
				'contenido' => view('configuracion/usuarios/info', compact('usuario')),
			];
			return view('plantilla', $params);
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			\Session::put('error', trans('configuracion.usuario_desconocido'));
			return \Redirect::action('Configuracion\Usuarios@getIndex');
		}
	}

	public function postInfo(){
		$salida = '';
		try {

			$usuario = \App\Models\Usuario::findOrFail(\Input::get('id'));
			switch(\Input::get('operacion')){

				case 'datos_personales':
					$sql = 'select id from usuarios where email=? and id<>?';
					$res = \DB::select($sql, [\Input::get('email'), $usuario->id]);
					if(count($res) == 0){
						$usuario->email = \Input::get('email');
						$usuario->nombre = \Input::get('nombre');
						$usuario->apellidos = \Input::get('apellidos');
						if(\Input::has('perfil')) $usuario->perfil = \Input::get('perfil');
						$usuario->save();
					} else {
						$salida = trans('configuracion.usuario_existe');
					}
				break;

				case 'cambiar_password':
					$usuario->password = bcrypt(\Input::get('password'));
					$usuario->save();
				break;

			}

		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('configuracion.usuario_desconocido');
		}
		return \Response::json($salida);
	}

	public function getPermisos($id = 0){
		$salida = array();
		try {
			$usuario = \App\Models\Usuario::findOrFail($id);
			$permisos = \Config::get('permisos.lista');
			foreach($permisos as $seccion => $lista){
				foreach($lista as $permiso => $descripcion){
					$salida[$permiso] = $usuario->puede($permiso);
				}
			}
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){}
		return \Response::json($salida);
	}

	public function postPermisos(){
		$salida = '';
		try {

			$usuario = \App\Models\Usuario::findOrFail(\Input::get('id'));
			if($usuario->puede('admin') && !\Input::has('permiso_admin')){
				$usuario->unsetPermiso('admin');
			}

			$input = \Input::all();
			$permisos = \Config::get('permisos.lista');
			foreach($permisos as $seccion => $lista){
				foreach($lista as $permiso => $descripcion){
					if(isset($input['permiso_'.$permiso])) $usuario->setPermiso($permiso);
					else $usuario->unsetPermiso($permiso);
				}
			}

		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('configuracion.usuario_desconocido');
		}
		return \Response::json($salida);
	}

	public function postEliminar(){
		$salida = '';
		try {
			$usuario = \App\Models\Usuario::findOrFail(\Input::get('id'));
			$login = \Auth::user();
			if($usuario->id != $login->id){
				$usuario->delete();
			} else {
				$salida = trans('configuracion.imposible_eliminar');
			}
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('configuracion.usuario_desconocido');
		}
		return \Response::json($salida);
	}

}
