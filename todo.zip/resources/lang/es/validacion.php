<?php

  return [
    'campo_requerido' => 'El campo [campo] no puede estar en blanco',
    'check_requerido' => 'Debes marcar el campo [campo]',
    'radio_requerido' => 'Debes seleccionar una opción del campo [campo]',
    'entero_invalido' => 'El campo [campo] debe contener un número entero válido',
    'decimal_invalido' => 'El campo [campo] debe contener un número decimal válido',
    'email_invalido' => 'El campo [campo] debe contener dirección de correo válida',
    'fecha_invalida' => 'El campo [campo] debe contener fecha válida',
    'hora_invalida' => 'El campo [campo] debe contener hora válida',
    'fecha_hora_invalida' => 'El campo [campo] debe contener fecha y hora válida',
  ];
