<footer id="footer">
  Copyright &copy; 2015 Material Admin
  <ul class="f-menu">
    <li><a href="">Home</a></li>
    <li><a href="">Dashboard</a></li>
    <li><a href="">Reports</a></li>
    <li><a href="">Support</a></li>
    <li><a href="">Contact</a></li>
  </ul>
</footer>
