<a class="btn btn-danger waves-effect" href="<?=\URL::action('ControlHorario@getCerrarSesion')?>" style="position: fixed; bottom: 20px; right: 20px; "><?=trans('base.cerrar_sesion')?></a>

<div class="col-sm-6 col-sm-push-3 p-t-0">

	<?
		$sql = 'select id from fichajes where id_trabajador=? and fin is null order by id desc limit 0, 1';
		$fichajes = \DB::select($sql, [$trabajador->id]);

		if(count($fichajes) == 0){
	?>
	<div class="card">
		<form id="iniciar_turno" name="iniciar_turno" method="POST" action="<?=\URL::action('ControlHorario@postIniciarTurno')?>" class="form-horizontal">
			<div class="card-header bgm-bluegray">
				<h2><?=trans('base.turno_actual')?></h2>
			</div>
			<div class="card-body card-padding text-center">
				<input type="hidden" name="_token" value="<?=csrf_token()?>">
				<p class="m-b-5"><?=trans('base.trabajador')?>: <?=$trabajador->nombre.' '.$trabajador->apellidos?></p>
				<p><?=trans('base.turno_no_iniciado')?></p>
				<?=view('ui/submit', ['label' => trans('base.iniciar_turno')])?>
			</div>
		</form>
	</div>
	<?
		} else {
			$fichaje = \App\Models\Fichaje::findOrFail($fichajes[0]->id);
	?>
	<div class="card">
		<form id="finalizar_turno" name="finalizar_turno" method="POST" action="<?=\URL::action('ControlHorario@postFinalizarTurno')?>" class="form-horizontal">
			<div class="card-header bgm-bluegray">
				<h2><?=trans('base.turno_actual')?></h2>
			</div>
			<div class="card-body card-padding text-center">
				<input type="hidden" name="_token" value="<?=csrf_token()?>">
				<p class="m-b-5"><?=trans('base.trabajador')?>: <?=$trabajador->nombre.' '.$trabajador->apellidos?></p>
				<p class="m-b-5"><?=trans('base.inicio_turno')?>: <?=date('j/n/Y G:i:s', strtotime($fichaje->inicio))?></p>
				<p class="m-b-5"><?=trans('base.hora_actual')?>: <span id="hora"><?=date('j/n/Y G:i:s')?></span></p>
				<h4 class="f-300 m-t-20 m-b-25" style="color: #5e5e5e;"><?=trans('base.tiempo_transcurrido')?>: <span id="tiempo" class="f-700"></span></h4>
				<?=view('ui/submit', ['label' => trans('base.finalizar_turno')])?>
			</div>
		</form>
	</div>
	<script>

		var hora_inicio = new Date(<?=strtotime($fichaje->inicio) * 1000?>);

		function segundero(){

			var pad = '00';

			var h = new Date();
			var hora_actual = h.getDate() + '/' + (h.getMonth() + 1) + '/' + h.getFullYear() + ' ' + h.getHours() + ':' + (pad + h.getMinutes()).slice(-pad.length) + ':' + (pad + h.getSeconds()).slice(-pad.length);
			$('#hora').html(hora_actual);

			var s = Math.floor((h.getTime() - hora_inicio.getTime()) / 1000);
			var m = Math.floor(s / 60);
			s = Math.floor(s % 60);
			var h = Math.floor(m / 60);
			m = Math.floor(m % 60);
			var d = Math.floor(h / 24);
			h = Math.floor(h % 24);

			var tiempo = '';
			if(d > 0) tiempo += d + '<?=trans('base.d')?> ';
			if(h > 0 || tiempo != '') tiempo += h + '<?=trans('base.h')?> ';
			if(m > 0 || tiempo != '') tiempo += m + '<?=trans('base.m')?> ';
			tiempo += s + '<?=trans('base.s')?> ';

			$('#tiempo').html(tiempo);

		}

		$(document).ready(function(){
			segundero();
			setInterval(segundero, 1000);
		});

	</script>
	<? } ?>

	<?
		$inicio_periodo = null;
		switch($trabajador->intervalo){
			case 'dia':
				$inicio_periodo = strtotime('today');
				$fin_periodo = strtotime('+1 day', $inicio_periodo);
			break;
			case 'semana':
				$inicio_periodo = strtotime('monday this week');
				$fin_periodo = strtotime('+7 day', $inicio_periodo);
			break;
			case 'mes':
				$inicio_periodo = strtotime('first day of');
				$fin_periodo = strtotime('+1 month', $inicio_periodo);
			break;
			case 'año':
				$inicio_periodo = strtotime('first day of january '.date('Y'));
				$fin_periodo = strtotime('+1 year', $inicio_periodo);
			break;
		}
		if(!is_null($inicio_periodo)){
	?>

	<div class="card">
		<div class="card-header bgm-bluegray">
			<h2><?=trans('base.periodo_actual')?>: <?=date('j/n/y', $inicio_periodo)?> - <?=date('j/n/y', $fin_periodo - 1)?></h2>
		</div>
		<div class="card-body card-padding p-b-0">

			<?

				$horas_realizadas = 0;
				$sql = 'select * from fichajes where id_trabajador=? and not(fin<? or inicio>?) order by inicio desc';
				$fichajes = \DB::select($sql, [$trabajador->id, date('Y-m-d H:i:s', $inicio_periodo), date('Y-m-d H:i:s', $fin_periodo)]);
				foreach($fichajes as $fichaje){
					$inicio = max($inicio_periodo, strtotime($fichaje->inicio));
					$fin = min($fin_periodo, strtotime($fichaje->fin));
					$horas_realizadas += round(($fin - $inicio) / 60 / 60, 2);
				}
				$diferencia = $trabajador->horas - $horas_realizadas;

				if(floatval($trabajador->horas) > 0){
			?>
			<p class="m-b-5"><?=trans('base.horas_contrato')?>: <?=strval(floatval($trabajador->horas))?><?=trans('base.h')?> / <?=trans('base.'.$trabajador->intervalo)?></p>
			<p class="m-b-5"><?=trans('base.horas_realizadas')?>: <?=$horas_realizadas?></p>
			<p class="m-b-15"><?=trans('base.diferencia')?>: <?=($diferencia >= 0)?trans('base.faltan'):trans('base.sobran')?> <?=abs($diferencia)?><?=trans('base.h')?></p>
			<? } ?>

		</div>
		<div class="table-responsive" tabindex="4" style="overflow: hidden; outline: none;">
	    <table class="table table-condensed">
				<? if(count($fichajes) > 0){ ?>
	      <thead>
          <tr>
            <th><?=trans('base.inicio_fichaje')?></th>
            <th><?=trans('base.fin_fichaje')?></th>
            <th><?=trans('base.horas_fichaje')?></th>
          </tr>
	      </thead>
				<? } ?>
        <tbody>
					<?
						if(count($fichajes) > 0){
							foreach($fichajes as $fichaje){
								$inicio = max($inicio_periodo, strtotime($fichaje->inicio));
								$fin = min($fin_periodo, strtotime($fichaje->fin));
					?>
					<tr>
            <td><?=date('j/n/y G:i:s', $inicio)?></td>
						<td><?=date('j/n/y G:i:s', $fin)?></td>
            <td><?=round(($fin - $inicio) / 60 / 60, 2)?></td>
          </tr>
					<? }} else { ?>
					<tr>
            <td colspan="3" class="p-t-20 p-b-20 text-center"><?=trans('base.no_hay_fichajes')?></td>
          </tr>
					<? } ?>
        </tbody>
      </table>
    </div>
	</div>

	<?

		switch($trabajador->intervalo){
			case 'dia':
				$inicio_periodo = strtotime('-1 day', $inicio_periodo);
				$fin_periodo = strtotime('+1 day', $inicio_periodo);
			break;
			case 'semana':
				$inicio_periodo = strtotime('-7 day', $inicio_periodo);
				$fin_periodo = strtotime('+7 day', $inicio_periodo);
			break;
			case 'mes':
				$inicio_periodo = strtotime('-1 month', $inicio_periodo);
				$fin_periodo = strtotime('+1 month', $inicio_periodo);
			break;
			case 'año':
				$inicio_periodo = strtotime('-1 year', $inicio_periodo);
				$fin_periodo = strtotime('+1 year', $inicio_periodo);
			break;
		}

	?>

	<div class="card">
		<div class="card-header bgm-bluegray">
			<h2><?=trans('base.periodo_anterior')?>: <?=date('j/n/y', $inicio_periodo)?> - <?=date('j/n/y', $fin_periodo - 1)?></h2>
		</div>
		<div class="card-body card-padding">

			<?

				$horas_realizadas = 0;
				$sql = 'select * from fichajes where id_trabajador=? and not(fin<? or inicio>?) order by inicio desc';
				$fichajes = \DB::select($sql, [$trabajador->id, date('Y-m-d H:i:s', $inicio_periodo), date('Y-m-d H:i:s', $fin_periodo)]);
				foreach($fichajes as $fichaje){
					$inicio = max($inicio_periodo, strtotime($fichaje->inicio));
					$fin = min($fin_periodo, strtotime($fichaje->fin));
					$horas_realizadas += round(($fin - $inicio) / 60 / 60, 2);
				}
				$diferencia = $trabajador->horas - $horas_realizadas;

				if(floatval($trabajador->horas) > 0){
			?>
			<p class="m-b-5"><?=trans('base.horas_contrato')?>: <?=strval(floatval($trabajador->horas))?><?=trans('base.h')?> / <?=trans('base.'.$trabajador->intervalo)?></p>
			<p class="m-b-5"><?=trans('base.horas_realizadas')?>: <?=$horas_realizadas?></p>
			<p class="m-b-5"><?=trans('base.diferencia')?>: <?=($diferencia >= 0)?trans('base.faltan'):trans('base.sobran')?> <?=abs($diferencia)?><?=trans('base.h')?></p>
			<? } ?>

		</div>
		<div class="table-responsive" tabindex="4" style="overflow: hidden; outline: none;">
	    <table class="table table-condensed">
				<? if(count($fichajes) > 0){ ?>
	      <thead>
          <tr>
            <th><?=trans('base.inicio_fichaje')?></th>
            <th><?=trans('base.fin_fichaje')?></th>
            <th><?=trans('base.horas_fichaje')?></th>
          </tr>
	      </thead>
				<? } ?>
        <tbody>
					<?
						if(count($fichajes) > 0){
							foreach($fichajes as $fichaje){
								$inicio = max($inicio_periodo, strtotime($fichaje->inicio));
								$fin = min($fin_periodo, strtotime($fichaje->fin));
					?>
					<tr>
            <td><?=date('j/n/y G:i:s', $inicio)?></td>
						<td><?=date('j/n/y G:i:s', $fin)?></td>
            <td><?=round(($fin - $inicio) / 60 / 60, 2)?></td>
          </tr>
					<? }} else { ?>
					<tr>
            <td colspan="3" class="p-t-20 p-b-20 text-center"><?=trans('base.no_hay_fichajes')?></td>
          </tr>
					<? } ?>
        </tbody>
      </table>
    </div>
	</div>

	<? } ?>

</div>
