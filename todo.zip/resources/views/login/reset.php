<?=view('login/cabecera')?>
<body class="login-content">

  <!-- Login -->
  <div class="lc-block toggled" id="l-login">

    <form name="login" method="post" action="<?=\URL::action('Login@postReset')?>" onsubmit="return validar(this)">
      <input type="hidden" name="_token" value="<?=csrf_token()?>">
      <input type="hidden" name="token" value="<?=$token?>">

      <div class="input-group m-b-20">
        <span class="input-group-addon"><i class="md md-https"></i></span>
        <div class="fg-line">
          <input name="password" type="password" class="form-control" placeholder="<?=trans('login.nuevo_password')?>">
        </div>
      </div>

      <div class="input-group m-b-20">
        <span class="input-group-addon"><i class="md md-https"></i></span>
        <div class="fg-line">
          <input name="repetir_password" type="password" class="form-control" placeholder="<?=trans('login.repetir_password')?>">
        </div>
      </div>

      <div class="clearfix"></div>

      <a class="btn btn-login btn-danger btn-float bgm-green" onclick="$('input#reset').trigger('click');"><i class="md md-arrow-forward"></i></a>
      <input type="submit" id="login" style="display:none">
    </form>

    <script>
        function validar(f){
          if(f.password.value.trim() == ''){ swal('<?=trans('login.ops')?>', '<?=trans('login.password_vacio')?>', 'error'); return false; }
          if(f.password.value.trim().length < 5){ swal('<?=trans('login.ops')?>', '<?=trans('login.password_corto')?>', 'error'); return false; }
          if(f.repetir_password.value.trim() == ''){ swal('<?=trans('login.ops')?>', '<?=trans('login.repetir_password_vacio')?>', 'error'); return false; }
          if(f.password.value.trim() != f.repetir_password.value.trim()){ swal('<?=trans('login.ops')?>', '<?=trans('login.password_no_coincide')?>', 'error'); return false; }
          return true;
        }
      </script>

    <ul class="login-navigation">
      <a href="<?=\URL::action('Login@getIndex')?>" class="btn bgm-blue waves-effect waves-button waves-float"><?=trans('login.volver')?></a>
    </ul>
  </div>

  <?=view('ui/navegador_viejo')?>

  <!-- Javascript Libraries -->
  <script src="<?=asset('vendors/bower_components/jquery/dist/jquery.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/bootstrap/dist/js/bootstrap.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/Waves/dist/waves.min.js')?>"></script>

  <!-- Placeholder for IE9 -->
  <!--[if IE 9 ]>
    <script src="<?=asset('vendors/bower_components/jquery-placeholder/jquery.placeholder.min.js')?>"></script>
  <![endif]-->

  <script src="<?=asset('js/functions.js')?>"></script>

</body>
</html>
