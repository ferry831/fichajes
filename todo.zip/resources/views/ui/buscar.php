<!-- Top Search Content -->
<div id="top-search-wrap">
  <input type="text">
  <i id="top-search-close">&times;</i>
</div>
