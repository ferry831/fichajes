<div class="block-header">
  <h2><?=trans('base.informe_fichajes')?></h2>
</div>

<div class="col-sm-12">

	<div class="card">
    <div class="card-body card-padding">
      <form class="row filtro" role="form" onsubmit="return validar_filtro(this)" method="post" action="<?=\URL::action('Informes@postFichajes')?>">
				<input type="hidden" name="_token" value="<?=csrf_token()?>">
        <div class="col-sm-6">
					<?
						$nombre = 'id_trabajador';
						$label = trans('base.trabajador');
						$inline = true;
						$opciones = array();
						$opciones[] = array('label' => trans('base.todos'), 'valor' => '0');
						$sql = 'select id, nombre, apellidos, nif from trabajadores where id_empresa=? order by nombre, apellidos';
						$trabajadores = \DB::select($sql, [$empresa->id]);
						foreach($trabajadores as $trabajador){
							$opciones[] = array('label' => $trabajador->nif.' - '.$trabajador->nombre.' '.$trabajador->apellidos, 'valor' => $trabajador->id);
						}
						$valor = $id_trabajador;
						echo view('ui/select', compact('nombre', 'label', 'inline', 'opciones', 'valor'));
					?>
        </div>
				<div class="col-sm-3">
					<?
						$nombre = 'fecha_inicio';
						$label = trans('base.fecha_inicio');
						$requerido = true;
						$inline = true;
						$valor = date('d/m/Y', $fecha_inicio);
						$validar = 'fecha';
						echo view('ui/input', compact('nombre', 'label', 'inline', 'validar', 'valor', 'requerido'));
					?>
        </div>
				<div class="col-sm-3">
					<?
						$nombre = 'fecha_fin';
						$label = trans('base.fecha_fin');
						$requerido = true;
						$inline = true;
						$valor = date('d/m/Y', $fecha_fin);
						$validar = 'fecha';
						echo view('ui/input', compact('nombre', 'label', 'inline', 'validar', 'valor', 'requerido'));
					?>
        </div>
        <div class="col-sm-12 text-right m-t-20">
          <button type="submit" class="btn btn-primary btn-sm m-t-5 waves-effect"><?=trans('base.generar_informe')?></button>
        </div>
      </form>
    </div>
	</div>

  <? if(count($trabajadores) > 0){ ?>
  <div class="text-right"><a class="btn btn-primary btn-sm m-r-25 m-b-15 waves-effect" style="position: relative; top: -10px;" onclick="pdf(0)"><?=trans('base.descargar_todo_pdf')?></a></div>
  <? } ?>

  <?

    $sql = 'select id from trabajadores where id_empresa=?';
    $params = [$empresa->id];
    if($id_trabajador > 0){
      $sql .= ' and id=?';
      $params[] = $id_trabajador;
    }

    $fecha_fin = strtotime('+1 day', $fecha_fin);

    $trabajadores = \DB::select($sql, $params);
    foreach($trabajadores as $trabajador){
      $trabajador = \App\Models\Trabajador::find($trabajador->id);
      if(!is_null($trabajador)){

  ?>

  <div class="card">
    <?
      $horas_realizadas = 0;
      $sql = 'select * from fichajes where id_trabajador=? and not(fin<? or inicio>?) order by inicio asc';
      $fichajes = \DB::select($sql, [$trabajador->id, date('Y-m-d H:i:s', $fecha_inicio), date('Y-m-d H:i:s', $fecha_fin)]);
      foreach($fichajes as $fichaje){
        $inicio = max($fecha_inicio, strtotime($fichaje->inicio));
        $fin = min($fecha_fin, strtotime($fichaje->fin));
        $horas_realizadas += round(($fin - $inicio) / 60 / 60, 2);
      }
    ?>
		<div class="card-header bgm-bluegray">
			<h2>
        <?=$trabajador->nif.' - '.$trabajador->nombre.' '.$trabajador->apellidos?>
        <a onclick="pdf(<?=$trabajador->id?>)" class="btn btn-primary pull-right waves-effect" style="position: relative; top: -6px;"><?=trans('base.descargar_pdf')?></a>
      </h2>
		</div>
		<div class="table-responsive p-t-10" tabindex="4" style="overflow: hidden; outline: none;">
	    <table class="table table-condensed">
				<? if(count($fichajes) > 0){ ?>
	      <thead>
          <tr>
            <th><?=trans('base.inicio_fichaje')?></th>
            <th><?=trans('base.fin_fichaje')?></th>
            <th><?=trans('base.horas_fichaje')?></th>
          </tr>
	      </thead>
				<? } ?>
        <tbody>
					<?
						if(count($fichajes) > 0){
							foreach($fichajes as $fichaje){
								$inicio = max($fecha_inicio, strtotime($fichaje->inicio));
								$fin = min($fecha_fin, strtotime($fichaje->fin));
					?>
					<tr>
            <td><?=date('j/n/y G:i:s', $inicio)?></td>
						<td><?=date('j/n/y G:i:s', $fin)?></td>
            <td><?=number_format(round(($fin - $inicio) / 60 / 60, 2), 2, '.', '')?></td>
          </tr>
					<? } ?>
          <tr>
            <td>&nbsp;</td>
						<td>&nbsp;</td>
            <td class="f-700 c-black"><?=number_format($horas_realizadas, 2, '.', '')?></td>
          </tr>
          <? } else { ?>
					<tr>
            <td colspan="3" class="p-t-20 p-b-25 text-center" style="border-top: 0;"><?=trans('base.no_hay_fichajes')?></td>
          </tr>
					<? } ?>
        </tbody>
      </table>
    </div>
	</div>

  <? }} ?>

</div>

<script>

	$(document).ready(function(){
		$('form.filtro label').css({position: 'relative', top: '5px'});
	});

	function validar_filtro(f){
		var inicio = f.fecha_inicio.value.split('/');
		inicio = new Date(parseInt(inicio[2], 10), parseInt(inicio[1], 10) - 1, parseInt(inicio[0], 10));
		var fin = f.fecha_fin.value.split('/');
		fin = new Date(parseInt(fin[2], 10), parseInt(fin[1], 10) - 1, parseInt(fin[0], 10));
		if(inicio.getTime() > fin.getTime()){
			ui_error_validacion('<?=trans('base.fechas_invalidas')?>');
			return false;
		}
		return true;
	}

  function pdf(id){
    document.generar_pdf.id_trabajador.value = id;
    document.generar_pdf.submit();
  }

</script>

<form name="generar_pdf" action="<?=\URL::action('Informes@postPdfFichajes')?>" method="POST">
  <input type="hidden" name="_token" value="<?=csrf_token()?>">
  <input type="hidden" name="id_trabajador" value="0">
  <input type="hidden" name="fecha_inicio" value="<?=$fecha_inicio?>">
  <input type="hidden" name="fecha_fin" value="<?=$fecha_fin?>">
</form>
