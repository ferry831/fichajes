<?

	if(!isset($id)) 						$id = 'input-'.md5(microtime().rand(0, 999999));
	if(!isset($nombre)) 				$nombre = '';
	if(!isset($valor)) 					$valor = '';
	if(!isset($placeholder)) 		$placeholder = '';
	if(!isset($label)) 					$label = '';
	if(!isset($campo)) 					$campo = '';
	if(!isset($clases)) 				$clases = [];
	if(!isset($readonly)) 			$readonly = false;
	if(!isset($disabled)) 			$disabled = false;
	if(!isset($requerido)) 			$requerido = false; // o true o texto de validacion
	if(!isset($ayuda)) 					$ayuda = '';
	if(!isset($inline))					$inline = false;
	if(!isset($filas))					$filas = 0;
	if(!isset($autosize))				$autosize = false;

	if($campo == '') $campo = $label;
	if($inline && $label == '') $label = '&nbsp;';
	if($autosize){
		$filas = 0;
		$clases[] = 'auto-size';
	}

?>
<div class="form-group">
  <? if($label != ''){ ?><label class="control-label <?=($inline)?'col-sm-3':''?>" for="<?=htmlentities($id)?>"><?=$label?></label><? } ?>
	<div class="<?=($inline)?'col-sm-9':''?>">
    <div class="fg-line">
	    <textarea
	      id="<?=htmlentities($id)?>"
				campo="<?=htmlentities($campo)?>"
	    	class="form-control input-sm <?=implode(' ', $clases)?>"
				<? if($readonly) 							echo 'readonly="readonly" '; ?>
	      <? if($disabled) 							echo 'disabled="disabled" '; ?>
	    	<? if($nombre != '') 					echo 'name="'.htmlentities($nombre).'" '; ?>
	    	<? if($placeholder != '') 		echo 'placeholder="'.htmlentities($placeholder).'" '; ?>
				<? if($filas > 0) 						echo 'rows="'.$filas.'" '; ?>
				<? if($requerido !== false) 	echo 'requerido="si" '; ?>
				<? if(is_string($requerido))	echo 'texto-requerido="'.htmlentities($requerido).'" '?>
	    ><? if($valor != '') echo htmlentities($valor); ?></textarea>
		</div>
  </div>
  <div class="<?=($inline)?'col-sm-offset-3 col-sm-9':''?>">
    <? if($ayuda != ''){ ?><small class="help-block"><?=$ayuda?></small><? } ?>
  </div>
</div>
