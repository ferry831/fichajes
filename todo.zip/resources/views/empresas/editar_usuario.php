<div class="modal fade" id="editarUsuarioEmpresa" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form class="form-horizontal" role="form" method="post" action="<?=(!$perfil_empresa)?\URL::action('Empresas@postInfoUsuario'):\URL::action('Empresa@postInfoUsuario')?>" onsubmit="return validar_editar_usuario(this)">
        <div class="modal-header">
          <h4 class="modal-title"><?=trans('base.editar_usuario')?></h4>
        </div>
        <div class="modal-body">
          <input type="hidden" name="_token" value="<?=csrf_token()?>">
          <input type="hidden" name="id_empresa" value="<?=$empresa->id?>">
          <input type="hidden" name="id_usuario" value="">
          <?

            $inline = true;

            ?><p class="f-700"><?=trans('base.datos_usuario')?></p><?

            $nombre = 'nombre';
            $label = trans('base.nombre');
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

            $nombre = 'apellidos';
            $label = trans('base.apellidos');
            echo view('ui/input', compact('nombre', 'label', 'inline'));

            $nombre = 'email';
            $label = trans('base.email');
            $validar = 'email';
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido', 'validar'));

            ?><p class="f-700"><?=trans('base.cambiar_password')?></p><?

            $nombre = 'password';
            $label = trans('base.password');
            echo view('ui/input', compact('nombre', 'label', 'inline'));

          ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal"><?=trans('base.cerrar')?></button>
          <?=view('ui/submit', ['label' => trans('base.guardar')])?>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  function validar_editar_usuario(f){
    if(f.password.value.trim().length > 0 && f.password.value.trim().length < 5 ){ swal('<?=trans('base.error')?>', '<?=trans('configuracion.password_corto')?>', 'error'); return false; }
    return true;
  }
</script>
