<?
  if(!isset($label))  $label = trans('base.guardar');
  if(!isset($clases)) $clases = [];
?>
<button type="submit" class="btn btn-primary waves-effect <?=implode(' ', $clases)?>"><?=$label?></button>
