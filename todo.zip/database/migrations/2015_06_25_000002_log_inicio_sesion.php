<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class LogInicioSesion extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up(){
		Schema::create('log_inicio_sesion', function(Blueprint $table){
			$table->bigIncrements('id');
			$table->bigInteger('id_usuario')->unsigned()->nullable()->index();
			$table->foreign('id_usuario')->references('id')->on('usuarios')->onDelete('set null');
			$table->string('nombre');
			$table->string('apellidos');
			$table->string('email');
			$table->string('ip');
			$table->enum('error', ['', 'auth_incorrecto', 'sin_permisos'])->default('');
			$table->dateTime('created_at');
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down(){
		Schema::drop('log_inicio_sesion');
	}

}
