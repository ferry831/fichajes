<div class="modal fade" id="editarFichaje" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form class="form-horizontal" role="form" method="post" ajax="true" action="<?=\URL::action('Trabajadores@postEditarFichaje')?>" onsubmit="return validar_fichaje(this)" onajax="$('#editarFichaje').modal('hide'); $('#listado_fichajes').bootgrid('reload');">
        <div class="modal-header">
          <h4 class="modal-title"><?=trans('base.editar_fin')?></h4>
        </div>
        <div class="modal-body">
          <input type="hidden" name="_token" value="<?=csrf_token()?>">
          <input type="hidden" name="id_fichaje" value="">
					<input type="hidden" name="id_trabajador" value="<?=$trabajador->id?>">
          <?

            $inline = true;

            $nombre = 'inicio';
            $label = trans('base.fecha_hora_inicio');
						$validar = 'fecha_hora';
						$requerido = true;
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido', 'validar'));

          ?>
          <?

            $inline = true;

            $nombre = 'fin';
            $label = trans('base.fecha_hora_fin');
						$validar = 'fecha_hora';
						$requerido = true;
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido', 'validar'));

          ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger pull-left eliminar"><?=trans('base.eliminar')?></button>
          <button type="button" class="btn btn-default" data-dismiss="modal"><?=trans('base.cerrar')?></button>
          <?=view('ui/submit', ['label' => trans('base.guardar')])?>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  function validar_fichaje(f){

		var inicio = f.inicio.value.split(' ');
		var fecha_inicio = inicio[0].split('/');
		var hora_inicio = inicio[1].split(':');
		inicio = new Date(parseInt(fecha_inicio[2], 10), parseInt(fecha_inicio[1], 10) - 1, parseInt(fecha_inicio[0], 10), parseInt(hora_inicio[0], 10), parseInt(hora_inicio[1], 10));

		var fin = f.fin.value.split(' ');
		var fecha_fin = fin[0].split('/');
		var hora_fin = fin[1].split(':');
		fin = new Date(parseInt(fecha_fin[2], 10), parseInt(fecha_fin[1], 10) - 1, parseInt(fecha_fin[0], 10), parseInt(hora_fin[0], 10), parseInt(hora_fin[1], 10));

		if(inicio.getTime() > fin.getTime()){
			ui_error_validacion('<?=trans('base.editar_fecha_invalida')?>');
			return false;
		}

    return true;
  }

  function eventos_editar_fichaje(){
    $('#editarFichaje .eliminar')
      .unbind('click')
      .click(function(){

        swal({
          title: "<?=trans('base.estas_seguro')?>",
          text: "<?=trans('base.no_undo')?>",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "<?=trans('base.si')?>",
          cancelButtonText: "<?=trans('base.no')?>",
          closeOnConfirm: true
        }, function(){

          var id_fichaje = $('#editarFichaje input[name="id_fichaje"]').val();
          var id_trabajador = $('#editarFichaje input[name="id_trabajador"]').val();

          $.post(
            '<?=\URL::action('Trabajadores@postEliminarFichaje')?>',
            { 
              id_fichaje: id_fichaje, 
              id_trabajador: id_trabajador, 
              _token: '<?=csrf_token()?>'
            },
            function(r){
              if(r != "") swal("<?=trans('base.error')?>", r, "error");
              else {
                
                $('#listado_fichajes').bootgrid('reload');
                $('#editarFichaje').modal('hide');

              }
            }
          );

        });

    });
  }

</script>
