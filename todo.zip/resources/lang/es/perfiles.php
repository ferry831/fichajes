<?php

	return array(

		'administrador' => 'Administrador',
		'empresa' => 'Empresa',

	);
