<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Fichajes extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up(){

		Schema::create('fichajes', function(Blueprint $table){
			$table->bigIncrements('id');
			$table->bigInteger('id_trabajador')->unsigned()->index();
			$table->foreign('id_trabajador')->references('id')->on('trabajadores')->onDelete('cascade');
			$table->dateTime('inicio');
			$table->dateTime('fin')->nullable();
		});

	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down(){
		Schema::drop('fichajes');
	}

}
