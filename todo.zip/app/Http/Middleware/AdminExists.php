<?php namespace App\Http\Middleware;

use Closure;

class AdminExists {
	public function handle($request, Closure $next){
		if(\App\Models\Usuario::all()->count() == 0){
			\App\Models\Usuario::create([
        'email' => 'admin@microvlc.es',
        'password' => bcrypt('admin'),
        'perfil' => 'administrador',
      ]);
      $admin = \App\Models\Usuario::where('email', 'admin@microvlc.es')->first();
      $admin->setPermiso('admin');
		}
		return $next($request);
	}
}
