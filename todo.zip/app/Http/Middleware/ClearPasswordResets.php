<?php namespace App\Http\Middleware;

use Closure;

class ClearPasswordResets {

	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @return mixed
	 */
	public function handle($request, Closure $next){
		// eliminamos tokens de recuperación de contraseña antiguos
		$sql = 'update usuarios set reset_token = null, reset_token_time = null where not reset_token is null and timestampdiff(HOUR, reset_token_time, now()) > 12';
		\DB::delete($sql);
		return $next($request);
	}

}
