<?=trans('login.instrucciones_reset_email')?><br/>
<a href="<?=\URL::action('Login@getReset', [$token])?>"><?=\URL::action('Login@getReset', [$token])?></a>
