<?php

  if(!isset($id)) 						$id = 'input-'.md5(microtime().rand(0, 999999));
  if(!isset($tipo)) 					$tipo = 'text';
	if(!isset($nombre)) 				$nombre = '';
	if(!isset($valor)) 					$valor = '';
	if(!isset($placeholder)) 		$placeholder = '';
	if(!isset($label)) 					$label = '';
  if(!isset($campo)) 					$campo = '';
	if(!isset($mascara)) 				$mascara = '';
	if(!isset($clases)) 				$clases = [];
	if(!isset($readonly)) 			$readonly = false;
	if(!isset($disabled)) 			$disabled = false;
  if(!isset($campo))          $campo = '';
	if(!isset($requerido)) 			$requerido = false; // o true o texto de validacion
	if(!isset($validar)) 				$validar = false;   // entero, decimal, email, fecha, hora, fecha_hora
	if(!isset($ayuda)) 					$ayuda = '';
	if(!isset($inline))					$inline = false;

  if($campo == '') $campo = $label;
	if($inline && $label == '') $label = '&nbsp;';

	switch($validar){
		case 'fecha': $mascara = '00/00/0000'; $placeholder = 'dd/mm/yyyy'; break;
		case 'hora': $mascara = '00:00'; $placeholder = 'hh:mm'; break;
		case 'fecha_hora': $mascara = '00/00/0000 00:00'; $placeholder = 'dd/mm/yyyy hh:mm'; break;
	}

?>
<div class="form-group">
  <? if($label != ''){ ?><label class="control-label <?=($inline)?'col-sm-3':''?>" for="<?=htmlentities($id)?>"><?=$label?></label><? } ?>
	<div class="<?=($inline)?'col-sm-9':''?>">
    <div class="fg-line">
	    <input
	      id="<?=htmlentities($id)?>"
	    	type="<?=$tipo?>"
        campo="<?=htmlentities($campo)?>"
	    	class="form-control input-sm <? if($mascara != '') echo 'input-mask'; ?> <?=implode(' ', $clases)?>"
	      <? if($mascara != '') 				echo 'data-mask="'.htmlentities($mascara).'" '; ?>
				<? if($readonly) 							echo 'readonly="readonly" '; ?>
	      <? if($disabled) 							echo 'disabled="disabled" '; ?>
	    	<? if($nombre != '') 					echo 'name="'.htmlentities($nombre).'" '; ?>
	    	<? if($placeholder != '') 		echo 'placeholder="'.htmlentities($placeholder).'" '; ?>
	    	<? if($valor != '' && $tipo != 'password') echo 'value="'.htmlentities($valor).'" '; ?>
				<? if($requerido !== false) 	echo 'requerido="si" '; ?>
				<? if(is_string($requerido))	echo 'texto-requerido="'.htmlentities($requerido).'" '?>
				<? if($validar !== false)			echo 'validar="'.htmlentities($validar).'" '; ?>
	    >
		</div>
  </div>
  <div class="<?=($inline)?'col-sm-offset-3 col-sm-9':''?>">
    <? if($ayuda != ''){ ?><small class="help-block"><?=$ayuda?></small><? } ?>
  </div>
</div>
