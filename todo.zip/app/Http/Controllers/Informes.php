<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;

class Informes extends Controller {

	public static $perfiles = ['empresa'];
	public static $permisos = [];

	public function getIndex(){
		return \Redirect::action('Informes@getFichajes');
	}

	public function getFichajes(){

		$usuario = \Auth::user();
		$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
		$empresa = \DB::select($sql, [$usuario->id]);

		if(count($empresa) == 0) return \Redirect::action('Login@getLogout');
		$empresa = \App\Models\Empresa::find($empresa[0]->id_empresa);
		if(is_null($empresa)) return \Redirect::action('Login@getLogout');

		$id_trabajador = \Session::get('fichajes_id_trabajador', 0);
		$fecha_inicio = \Session::get('fichajes_fecha_inicio', date('d/m/Y', strtotime('first day of '.date('l'))));
		$fecha_fin = \Session::get('fichajes_fecha_fin', date('d/m/Y', strtotime('last day of '.date('l'))));

		$fecha_inicio = strtotime(str_replace('/', '-', $fecha_inicio));
		$fecha_fin = strtotime(str_replace('/', '-', $fecha_fin));

		$params = [
			'menu' => 'informes',
			'submenu' => '',
			'contenido' => view('informes/fichajes', compact('empresa', 'id_trabajador', 'fecha_inicio', 'fecha_fin')),
		];
		return view('plantilla', $params);

	}

	public function postFichajes(){
		\Session::put('fichajes_id_trabajador', \Input::get('id_trabajador'));
		\Session::put('fichajes_fecha_inicio', \Input::get('fecha_inicio'));
		\Session::put('fichajes_fecha_fin', \Input::get('fecha_fin'));
		return \Redirect::action('Informes@getFichajes');
	}

	public function postPdfFichajes(){

		$usuario = \Auth::user();
		$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
		$empresa = \DB::select($sql, [$usuario->id]);

		if(count($empresa) == 0) return \Redirect::action('Login@getLogout');
		$empresa = \App\Models\Empresa::find($empresa[0]->id_empresa);
		if(is_null($empresa)) return \Redirect::action('Login@getLogout');

		$sql = 'select id from trabajadores where id_empresa=?';
		$params = [$empresa->id];
		if(intval(\Input::get('id_trabajador')) > 0){
			$sql .= ' and id=?';
			$params[] = \Input::get('id_trabajador');
		}
		$sql .= ' order by nombre, apellidos';
		$trabajadores = \DB::select($sql, $params);

		if(count($trabajadores) == 0){
			\Session::put('error', trans('base.no_hay_trabajadores'));
			return \Redirect::action('Informes@getFichajes');
		}

		$pdfs = array();
		foreach($trabajadores as $trabajador){
			$trabajador = \App\Models\Trabajador::find($trabajador->id);
			$pdfs[] = new \App\Models\InformeFichajesPdf($empresa, $trabajador, intval(\Input::get('fecha_inicio')), intval(\Input::get('fecha_fin')));
		}

		if(count($pdfs) == 1){
			return \Response::make($pdfs[0]->Output('informe.pdf', 'D'), 200, array('content-type'=>'application/pdf'));
		} else {
			$ficheros = [];
			foreach($pdfs as $pdf){
				do {
					$fichero = '../tmp/'.md5(time().rand(0, 9999)).'.pdf';
				} while(file_exists($fichero));
				$pdf->Output($fichero, 'F');
				$ficheros[] = $fichero;
			}
			$fpdi = new \fpdi\FPDI();
			foreach($ficheros as $fichero){
				$pageCount = $fpdi->setSourceFile($fichero);
				for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
	        $templateId = $fpdi->importPage($pageNo);
	        $size = $fpdi->getTemplateSize($templateId);
	        if ($size['w'] > $size['h']) $fpdi->AddPage('L', array($size['w'], $size['h']));
	        else $fpdi->AddPage('P', array($size['w'], $size['h']));
	        $fpdi->useTemplate($templateId);
		    }
				unlink($fichero);
			}
			return \Response::make($fpdi->Output('informe.pdf', 'D'), 200, array('content-type'=>'application/pdf'));
		}

	}

}
