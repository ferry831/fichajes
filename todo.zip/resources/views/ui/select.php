<?

  if(!isset($id)) 					$id = 'input-'.md5(microtime().rand(0, 999999));
  if(!isset($nombre)) 			$nombre = '';
  if(!isset($valor)) 				$valor = '';
  if(!isset($placeholder))  $placeholder = '';
  if(!isset($label)) 				$label = '';
  if(!isset($campo)) 				$campo = '';
  if(!isset($readonly)) 		$readonly = false;
  if(!isset($disabled)) 		$disabled = false;
  if(!isset($requerido)) 		$requerido = false; // o true o texto de validacion
  if(!isset($ayuda)) 				$ayuda = '';
  if(!isset($inline))				$inline = false;
  if(!isset($opciones))     $opciones = [];

  if($campo == '') $campo = $label;

?>
<div class="form-group">
  <? if($label != ''){ ?><label class="control-label <?=($inline)?'col-sm-3':''?>" for="<?=htmlentities($id)?>"><?=$label?></label><? } ?>
	<div class="<?=($inline)?'col-sm-9':''?>">

    <select
      id="<?=htmlentities($id)?>"
      class="tag-select"
      campo="<?=htmlentities($campo)?>"
      <? if($nombre != '') 					echo 'name="'.htmlentities($nombre).'" '; ?>
      <? if($placeholder != '') 		echo 'data-placeholder="'.htmlentities($placeholder).'" '; ?>
      <? if($requerido !== false) 	echo 'requerido="si" '; ?>
      <? if(is_string($requerido))	echo 'texto-requerido="'.htmlentities($requerido).'" '?>
      <? if($readonly) 							echo 'readonly="readonly" '; ?>
      <? if($disabled) 							echo 'disabled="disabled" '; ?>

    >
    <?
      foreach($opciones as $opcion){
        if(!is_array($opcion)) $opcion = ['valor' => $opcion];
        if(!isset($opcion['valor'])) $opcion['valor'] = '';
        if(!isset($opcion['label'])) $opcion['label'] = $opcion['valor'];
        if(!isset($opcion['disabled'])) $opcion['disabled'] = false;
    ?>
      <option value="<?=htmlentities($opcion['valor'])?>" <?=($opcion['disabled'])?'disabled="disabled"':''; ?> <?=($valor == $opcion['valor'])?'selected="selected"':''?>><?=$opcion['label']?></option>
    <? } ?>

    </select>
  </div>
  <div class="<?=($inline)?'col-sm-offset-3 col-sm-9':''?>">
    <? if($ayuda != ''){ ?><small class="help-block"><?=$ayuda?></small><? } ?>
  </div>
</div>
