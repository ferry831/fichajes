<?php namespace App\Console\Commands;

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class CierreAutomatico extends Command {

	/**
	 * The console command name.
	 *
	 * @var string
	 */
	protected $name = 'cierre_automatico';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Realiza el cierre automático de turnos';

	/**
	 * Execute the console command.
	 *
	 * @return mixed
	 */
	public function handle(){
		
		$desviacion = 10; // minutos
		$this->comment('buscando turnos abiertos');

		$sql = 'select f.id as id_fichaje, t.id as id_trabajador, t.hora_cierre as hora_cierre_trabajador, e.hora_cierre as hora_cierre_empresa, t.cierre_automatico_horario, t.turno_maximo, t.cierre_automatico_turno from fichajes f left join trabajadores t on f.id_trabajador=t.id left join empresas e on t.id_empresa=e.id where f.fin is null and (t.cierre_automatico_turno = 1 or t.cierre_automatico_horario = 1)';
		$turnos = \DB::select($sql);
		if(!is_null($turnos) && count($turnos) > 0){
			foreach($turnos as $turno){

				$fichaje = \App\Models\Fichaje::find($turno->id_fichaje);
				$inicio = strtotime($fichaje->inicio);

				if(is_null($fichaje->fin) && $turno->cierre_automatico_turno == 1 && $turno->turno_maximo > 0){

					$fin_turno = strtotime('+'.$turno->turno_maximo.' hours', $inicio);
					if($fin_turno <= time()){
						
						$fichaje->fin = date('Y-m-d H:i:s', $fin_turno + (rand(0, $desviacion * 60)));
						$fichaje->automatico = 1;
						$fichaje->save();

						$this->comment('cierre por turno máximo: ');
						print_r($fichaje->toArray());

					}

				}

				if(is_null($fichaje->fin) && $turno->cierre_automatico_horario == 1){

					$fin_turno = !is_null($turno->hora_cierre_trabajador) ? $turno->hora_cierre_trabajador : $turno->hora_cierre_empresa;
					$fin_turno = strtotime(date('Y-m-d').' '.$fin_turno);
					if($fin_turno < $inicio){
						$fin_turno = strtotime('+1 day', $fin_turno);
					}

					if($fin_turno <= time()){
						
						$fichaje->fin = date('Y-m-d H:i:s', $fin_turno + (rand(0, $desviacion * 60)));
						$fichaje->automatico = 1;
						$fichaje->save();

						$this->comment('cierre por turno horario: ');
						print_r($fichaje->toArray());

					}

				}

			}
		}

	}

}
