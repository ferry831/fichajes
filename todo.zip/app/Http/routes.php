<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::controller('fichar', 'ControlHorario');
Route::get('/a/{alias}', ['uses' => 'ControlHorario@getAlias']);

Route::controller('login', 'Login');
Route::group(['middleware' => 'auth'], function(){

	Route::get('/', function(){ return Redirect::route('inicio');	});
	Route::get('inicio', ['uses' => 'Inicio@index', 'as' => 'inicio']);

	Route::get('configuracion', function(){ return Redirect::action('Configuracion\Usuarios@getIndex');	});
	Route::controller('configuracion/usuarios', 'Configuracion\Usuarios');
	Route::controller('configuracion/perfil', 'Configuracion\Perfil');

	// administrador
	Route::controller('empresas', 'Empresas');

	// empresa
	Route::controller('empresa', 'Empresa');
	Route::controller('trabajadores', 'Trabajadores');
	Route::controller('informes', 'Informes');

});
