<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Trabajadores extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up(){

		Schema::create('trabajadores', function(Blueprint $table){
			$table->bigIncrements('id');
			$table->bigInteger('id_empresa')->unsigned()->index();
			$table->foreign('id_empresa')->references('id')->on('empresas')->onDelete('cascade');
			$table->string('nombre');
			$table->string('apellidos');
			$table->string('nif');
			$table->string('afiliacion');
			$table->string('pin', 4);
			$table->decimal('horas', 5, 2);
			$table->enum('intervalo', ['dia', 'semana', 'mes', 'año']);
			$table->timestamps();
			$table->unique(['id_empresa', 'nif']);
		});

	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down(){
		Schema::drop('trabajadores');
	}

}
