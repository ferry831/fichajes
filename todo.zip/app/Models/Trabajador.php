<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
class Trabajador extends Model {
	protected $table = 'trabajadores';

	public static function enviarAvisos(){

		$empresas = [];
		foreach(Empresa::all() as $empresa) $empresas[$empresa->id] = $empresa;

		$hoy = date('Y-m-d');
		$hora = explode(':', date('H:i'));
		$hora = $hora[0] * 60 + $hora[1];

		$dia = '';
		switch(date('w')){
			case 0: $dia = 'domingo'; break;
			case 1: $dia = 'lunes'; break;
			case 2: $dia = 'martes'; break;
			case 3: $dia = 'miercoles'; break;
			case 4: $dia = 'jueves'; break;
			case 5: $dia = 'viernes'; break;
			case 6: $dia = 'sabado'; break;
		}

		$trabajadores = Trabajador::where('email', '!=', '')->get();
		foreach($trabajadores as $trabajador){
			$sql = 'select count(*) as c from avisos where id_trabajador=? and fecha=?';
			$res = \DB::select($sql, [$trabajador->id, $hoy]);
			if($res[0]->c == 0){
				$avisos = json_decode((!is_null($trabajador->avisos_turno_no_iniciado)) ? $trabajador->avisos_turno_no_iniciado : $empresas[$trabajador->id_empresa]->avisos_turno_no_iniciado, true);
				if(!is_null($avisos[$dia])){
					$hora_aviso = $avisos[$dia];
					$hora_aviso = $hora_aviso[0] * 60 + $hora_aviso[1];
					if($hora >= $hora_aviso){
						$sql = 'select count(*) as c from fichajes where id_trabajador=? and fin is null';
						$res = \DB::select($sql, [$trabajador->id]);
						if($res[0]->c == 0){
							$aviso = new Aviso;
							$aviso->id_trabajador = $trabajador->id;
							$aviso->fecha = $hoy;
							$aviso->save();
							$aviso->enviar();
							echo 'enviado aviso a '.$trabajador->email.PHP_EOL;
						}
					}
				}
			}
		}

	}

	public function empresa(){
		return $this->belongsTo('App\Models\Empresa', 'id_empresa');
	}

}
