<!DOCTYPE html>
<!--[if IE 9 ]><html class="ie9"><![endif]-->
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?=\Config::get('app.nombre', 'Material Admin')?></title>

  <!-- Vendor CSS -->
  <link href="<?=asset('vendors/bootgrid/jquery.bootgrid.min.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/bower_components/animate.css/animate.min.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/bower_components/bootstrap-select/dist/css/bootstrap-select.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/bower_components/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/bower_components/fullcalendar/dist/fullcalendar.min.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/bower_components/lightgallery/light-gallery/css/lightGallery.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/bower_components/material-design-iconic-font/css/material-design-iconic-font.min.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/bower_components/mediaelement/build/mediaelementplayer.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/bower_components/nouislider/distribute/jquery.nouislider.min.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/bower_components/summernote/dist/summernote.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/bower_components/sweetalert/dist/sweetalert-override.min.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/chosen_v1.4.2/chosen.min.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/farbtastic/farbtastic.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/socicon/socicon.min.css')?>" rel="stylesheet">

  <!-- CSS -->
  <link href="<?=asset('css/app.min.1.css')?>" rel="stylesheet">
  <link href="<?=asset('css/app.min.2.css')?>" rel="stylesheet">
  <link href="<?=asset('css/material.css')?>" rel="stylesheet">

  <!-- Javascript Libraries -->
  <script src="<?=asset('vendors/bower_components/jquery/dist/jquery.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/bootstrap/dist/js/bootstrap.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/moment/min/moment.min.js')?>"></script>

</head>
<body class="p-t-20">

  <section id="main">

    <section id="content" class="p-0">
      <div class="container">
        <?=(isset($contenido))?$contenido:''?>
      </div>
    </section>

  </section>

  <?=(\Config::get('ui.footer', false) !== false) ? view(\Config::get('ui.footer')) : '';?>
  <?=view('ui/navegador_viejo')?>

  <!-- Javascript Libraries -->

  <script src="<?=asset('vendors/bower_components/autosize/dist/autosize.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/bootstrap-select/dist/js/bootstrap-select.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/jquery.nicescroll/jquery.nicescroll.min.js')?>"></script>

  <script src="<?=asset('vendors/bower_components/fullcalendar/dist/fullcalendar.min.js ')?>"></script>
  <script src="<?=asset('vendors/bower_components/lightgallery/light-gallery/js/lightGallery.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/mediaelement/build/mediaelement-and-player.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/nouislider/distribute/jquery.nouislider.all.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/simpleWeather/jquery.simpleWeather.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/summernote/dist/summernote.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/sweetalert/dist/sweetalert.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/Waves/dist/waves.min.js')?>"></script>

  <? if(isset($ui_flot) && $ui_flot){ ?>
  <script src="<?=asset('vendors/bower_components/flot/jquery.flot.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/flot/jquery.flot.resize.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/flot/jquery.flot.pie.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/flot.tooltip/js/jquery.flot.tooltip.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/flot.curvedlines/curvedLines.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/flot-orderBars/js/jquery.flot.orderBars.js')?>"></script>
  <? } ?>

  <script src="<?=asset('vendors/bootgrid/jquery.bootgrid.min.js')?>"></script>

  <script src="<?=asset('vendors/bootstrap-growl/bootstrap-growl.min.js')?>"></script>
  <script src="<?=asset('vendors/bootstrap-wizard/jquery.bootstrap.wizard.min.js')?>"></script>

  <script src="<?=asset('vendors/chosen_v1.4.2/chosen.jquery.min.js')?>"></script>
  <script src="<?=asset('vendors/fileinput/fileinput.min.js')?>"></script>
  <script src="<?=asset('vendors/farbtastic/farbtastic.min.js')?>"></script>
  <script src="<?=asset('vendors/sparklines/jquery.sparkline.min.js')?>"></script>
  <script src="<?=asset('vendors/input-mask/input-mask.min.js')?>"></script>

  <!-- Placeholder for IE9 -->
  <!--[if IE 9 ]>
    <script src="<?=asset('vendors/bower_components/jquery-placeholder/jquery.placeholder.min.js')?>"></script>
  <![endif]-->

  <script src="<?=asset('js/material.js')?>"></script>
  <script src="<?=asset('js/utiles.js')?>"></script>

  <? if(isset($ui_demo) && $ui_demo){ ?>
  <script src="<?=asset('js/charts.js')?>"></script>
  <script src="<?=asset('js/demo.js')?>"></script>
  <? } ?>

  <!-- Validación de formularios -->
  <script>
    <? $validaciones = \Lang::get('validacion'); foreach($validaciones as $clave => $valor){ ?>
    var ui_<?=$clave?> = <?=json_encode($valor)?>;
    <? } ?>
    var ui_cambios_guardados = <?=json_encode(trans('base.cambios_guardados'))?>;
    var ui_cerrar = <?=json_encode(trans('base.cerrar'))?>;
    function ui_error_validacion(error){
      swal(<?=json_encode(trans('base.error'))?>, error, 'error');
    }
    function ui_info(txt){
      info(txt, <?=json_encode(trans('base.cerrar'))?>);
    }
  </script>
  <script src="<?=asset('js/validar_ui.js')?>"></script>

  <script>
    $(document).ready(function(){
      <? if(\Session::has('error')){ ?>swal(<?=json_encode(trans('base.error'))?>, <?=json_encode(\Session::get('error'))?>, 'error');<? \Session::forget('error'); } ?>
      <? if(\Session::has('info')){ ?>info(<?=json_encode(\Session::get('info'))?>, <?=json_encode(trans('base.cerrar'))?>);<? \Session::forget('info'); } ?>
    });
  </script>

</body>
</html>
