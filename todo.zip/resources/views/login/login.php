<?=view('login/cabecera')?>
<body class="login-content">

  <!-- Login -->
  <div class="lc-block toggled" id="l-login">
    <form name="login" method="post" action="<?=\URL::action('Login@postLogin')?>" onsubmit="return validar(this)">
      <input type="hidden" name="_token" value="<?=csrf_token()?>">

      <div class="input-group m-b-20">
        <span class="input-group-addon"><i class="md md-person"></i></span>
        <div class="fg-line">
          <input name="usuario" type="text" class="form-control" placeholder="<?=trans('login.usuario')?>">
        </div>
      </div>

      <div class="input-group m-b-20">
        <span class="input-group-addon"><i class="md md-https"></i></span>
        <div class="fg-line">
          <input name="password" type="password" class="form-control" placeholder="<?=trans('login.password')?>">
        </div>
      </div>

      <div class="clearfix"></div>

      <div class="checkbox">
        <label>
          <input name="recuerdame" type="checkbox" value="recuerdame">
          <i class="input-helper"></i>
          <?=trans('login.recuerdame')?>
        </label>
      </div>

      <a class="btn btn-login btn-danger btn-float bgm-green" onclick="$('input#login').trigger('click');"><i class="md md-arrow-forward"></i></a>
      <input type="submit" id="login" style="display:none">
    </form>

    <script>

      function validar(f){
        if(f.usuario.value.trim() == ''){ swal('<?=trans('login.ops')?>', '<?=trans('login.usuario_vacio')?>', 'error'); return false; }
        if(f.password.value.trim() == ''){ swal('<?=trans('login.ops')?>', '<?=trans('login.password_vacio')?>', 'error'); return false; }
        return true;
      }

      $(document).ready(function(){ <?
        if(\Session::has('success')){ ?> swal('<?=trans('login.ook')?>', '<?=\Session::get('success')?>', 'success'); <? \Session::forget('success'); }
        if(\Session::has('error')){ ?> swal('<?=trans('login.ops')?>', '<?=\Session::get('error')?>', 'error'); <? \Session::forget('error'); }
      ?> });

    </script>

    <ul class="login-navigation">
      <a href="<?=\URL::action('Login@getOlvido')?>" class="btn btn-sm bgm-blue waves-effect waves-button waves-float"><?=trans('login.olvido_password')?></a>
    </ul>
  </div>

  <?=view('ui/navegador_viejo')?>

</body>
</html>
