<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;

class Trabajadores extends Controller {

	public static $perfiles = ['empresa'];
	public static $permisos = [];

	public function getIndex(){

		$usuario = \Auth::user();
		$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
		$empresa = \DB::select($sql, [$usuario->id]);

		if(count($empresa) == 0) return \Redirect::action('Login@getLogout');
		$empresa = \App\Models\Empresa::find($empresa[0]->id_empresa);
		if(is_null($empresa)) return \Redirect::action('Login@getLogout');

		$params = [
			'menu' => 'trabajadores',
			'submenu' => '',
			'contenido' => view('trabajadores/lista', compact('empresa')),
		];
		return view('plantilla', $params);

	}

	public function postListadoTrabajadores(){

		$output = new \stdClass();
		$output->current = \Input::get('current');
		$output->rowCount = \Input::get('rowCount');
		$output->rows = array();
		$output->total = 0;

		$usuario = \Auth::user();
		$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
		$empresa = \DB::select($sql, [$usuario->id]);

		try {
			$empresa = \App\Models\Empresa::find($empresa[0]->id_empresa);
		} catch(\Exception $e){
			return \Response::json($output);
		}

		$sql = 'select count(*) as c from trabajadores where id_empresa=?';
		$params = array($empresa->id);

		$res = \DB::select($sql, $params);
		if(isset($res[0]->c)) $output->total = $res[0]->c;

		if(trim(\Input::get('searchPhrase')) != ''){
			$sql .= ' and (nombre like ? or apellidos like ? or nif like ?)';
			$params[] = '%'.trim(\Input::get('searchPhrase')).'%';
			$params[] = '%'.trim(\Input::get('searchPhrase')).'%';
			$params[] = '%'.trim(\Input::get('searchPhrase')).'%';
		}

		$sort = \Input::get('sort');
		if(count($sort) > 0){
			$orden = array();
			foreach($sort as $id => $direccion){
				switch($id){
					case 'nombre': $orden[] = 'nombre '.$direccion; break;
					case 'apellidos': $orden[] = 'apellidos '.$direccion; break;
					case 'nif': $orden[] = 'nif '.$direccion; break;
				}
			}
			$sql .= ' order by '.implode(', ', $orden);
		}

		$sql = str_replace('count(*) as c', 'id, nombre, apellidos, nif', $sql);
		if(\Input::get('rowCount') > 0) $sql .= ' limit '.((\Input::get('current') - 1) * \Input::get('rowCount')).', '.(\Input::get('rowCount'));

		$resultados = \DB::select($sql, $params);
		if(count($resultados) > 0){
			foreach($resultados as $r){
				$r->botones = '';

				$r->estado = '<a class="btn btn-default btn-xs">'.trans('base.sin_turnos').'</a>';
				$r->inicio = '';
				$r->fin = '';
				$r->duracion = '';

				$fichaje = \App\Models\Fichaje::where('id_trabajador', $r->id)->orderBy('id', 'desc')->first();
				if(!is_null($fichaje)){
					$r->inicio = date('d/m/Y H:i', strtotime($fichaje->inicio));
					$r->duracion = $fichaje->duracion();
					if(is_null($fichaje->fin)){
						
						$r->estado = '<a class="btn btn-success btn-xs">'.trans('base.turno_abierto').'</a>';
						
					} else {

						$r->estado = '<a class="btn btn-danger btn-xs">'.trans('base.turno_cerrado').'</a>';
						$r->fin = date('d/m/Y H:i', strtotime($fichaje->fin));

					}
				}

				$output->rows[] = $r;
			}
		}

		return \Response::json($output);

	}

	public function postListadoFichajes($id_trabajador){

		$output = new \stdClass();
		$output->current = \Input::get('current');
		$output->rowCount = \Input::get('rowCount');
		$output->rows = array();
		$output->total = 0;

		$usuario = \Auth::user();
		$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
		$empresa = \DB::select($sql, [$usuario->id]);

		try {
			$empresa = \App\Models\Empresa::findOrFail($empresa[0]->id_empresa);
			$trabajador = \App\Models\Trabajador::findOrFail($id_trabajador);
		} catch(\Exception $e){
			return \Response::json($output);
		}

		if($trabajador->id_empresa != $empresa->id) return \Response::json($output);

		$sql = 'select count(*) as c from fichajes where id_trabajador=?';
		$params = array($trabajador->id);

		$res = \DB::select($sql, $params);
		if(isset($res[0]->c)) $output->total = $res[0]->c;

		$sort = \Input::get('sort');
		if(count($sort) > 0){
			$orden = array();
			foreach($sort as $id => $direccion){
				switch($id){
					case 'inicio': $orden[] = 'inicio '.$direccion; break;
					case 'fin': $orden[] = 'fin '.$direccion; break;
				}
			}
			$sql .= ' order by '.implode(', ', $orden);
		}

		$sql = str_replace('count(*) as c', 'id, inicio, fin', $sql);
		if(\Input::get('rowCount') > 0) $sql .= ' limit '.((\Input::get('current') - 1) * \Input::get('rowCount')).', '.(\Input::get('rowCount'));

		$resultados = \DB::select($sql, $params);
		if(count($resultados) > 0){
			foreach($resultados as $r){
				$r->duracion = '';
				if(!is_null($r->fin)) $r->duracion = round((strtotime($r->fin) - strtotime($r->inicio)) / 60 / 60, 2);
				$r->inicio = date('d/m/Y H:i', strtotime($r->inicio));
				if(!is_null($r->fin)) $r->fin = date('d/m/Y H:i', strtotime($r->fin));
				$r->botones = '';
				$output->rows[] = $r;
			}
		}

		return \Response::json($output);

	}

	public function postNuevo(){

		try {

			$usuario = \Auth::user();
			$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
			$empresa = \DB::select($sql, [$usuario->id]);
			$empresa = \App\Models\Empresa::find($empresa[0]->id_empresa);

			$trabajador = new \App\Models\Trabajador;
			$trabajador->id_empresa = $empresa->id;
			$trabajador->nombre = \Input::get('nombre');
			$trabajador->apellidos = \Input::get('apellidos');
			$trabajador->nif = \Input::get('nif');
			$trabajador->afiliacion = \Input::get('afiliacion');
			$trabajador->pin = rand(1000, 9999);
			$trabajador->save();

		} catch(\Exception $e){
			\Session::put('error', trans('base.error_creando_trabajador'));
			return \Redirect::action('Trabajadores@getIndex');
		}

		\Session::put('info', trans('base.trabajador_creado'));
		return \Redirect::action('Trabajadores@getInfo', [$trabajador->id]);

	}

	public function getInfo($id){
		try {

			$usuario = \Auth::user();
			$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
			$empresa = \DB::select($sql, [$usuario->id]);
			$empresa = \App\Models\Empresa::findOrFail($empresa[0]->id_empresa);

			$trabajador = \App\Models\Trabajador::findOrFail($id);
			if($trabajador->id_empresa != $empresa->id){
				\Session::put('error', trans('base.trabajador_desconocido'));
				return \Redirect::action('Trabajadores@getIndex');
			}

			$params = [
				'menu' => 'trabajadores',
				'submenu' => '',
				'contenido' => view('trabajadores/info', compact('empresa', 'trabajador')),
			];
			return view('plantilla', $params);
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			\Session::put('error', trans('base.trabajador_desconocido'));
			return \Redirect::action('Trabajadores@getIndex');
		}
	}

	public function postInfo(){
		$salida = '';
		try {

			$usuario = \Auth::user();
			$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
			$empresa = \DB::select($sql, [$usuario->id]);
			$empresa = \App\Models\Empresa::findOrFail($empresa[0]->id_empresa);

			$trabajador = \App\Models\Trabajador::findOrFail(\Input::get('id'));
			if($trabajador->id_empresa != $empresa->id){
				$salida = trans('base.trabajador_desconocido');
				return \Response::json($salida);
			}

			switch(\Input::get('operacion')){

				case 'datos_trabajador':
					$trabajador->nombre = \Input::get('nombre');
					$trabajador->apellidos = \Input::get('apellidos');
					$trabajador->nif = \Input::get('nif');
					$trabajador->centro_trabajo = \Input::get('centro_trabajo');
					$trabajador->afiliacion = \Input::get('afiliacion');
					$trabajador->hora_cierre = (\Input::has('hora_cierre_defecto')) ? null : \Input::get('hora_cierre');
					$trabajador->cierre_automatico_horario = \Input::has('cierre_automatico_horario');
					$trabajador->turno_maximo = max(0, intval(\Input::get('turno_maximo')));
					$trabajador->cierre_automatico_turno = \Input::has('cierre_automatico_turno');
					$trabajador->save();
				break;

				case 'contrato':
					$trabajador->horas = \Input::get('horas');
					$trabajador->intervalo = \Input::get('intervalo');
					$trabajador->save();
				break;

				case 'pin_acceso':
					$trabajador->pin = \Input::get('pin');
					$trabajador->save();
				break;

				case 'avisos_fichajes':
					$trabajador->email = \Input::get('email_aviso');
					$avisos = ['lunes' => null, 'martes' => null, 'miercoles' => null, 'jueves' => null, 'viernes' => null, 'sabado' => null, 'domingo' => null];
					foreach($avisos as $dia => $valor){
						if(\Input::has('hora_aviso_'.$dia)){
							$avisos[$dia] = \Input::get('hora_aviso_'.$dia);
						}
					}
					$trabajador->avisos_turno_no_iniciado = (\Input::has('avisos_defecto')) ? null : json_encode($avisos);
					$trabajador->save();
				break;

			}

		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.trabajador_desconocido');
		} catch(\Illuminate\Database\QueryException $e){
			$salida = trans('base.trabajador_duplicado');
		}
		return \Response::json($salida);
	}

	public function postEliminar(){
		$salida = '';
		try {

			$usuario = \Auth::user();
			$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
			$empresa = \DB::select($sql, [$usuario->id]);
			$empresa = \App\Models\Empresa::findOrFail($empresa[0]->id_empresa);

			$trabajador = \App\Models\Trabajador::findOrFail(\Input::get('id'));
			if($trabajador->id_empresa == $empresa->id) $trabajador->delete();
			else $salida = trans('base.trabajador_desconocido');

		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.trabajador_desconocido');
		}
		return \Response::json($salida);
	}

	public function postEditarFichaje(){
		$salida = '';
		try {

			$usuario = \Auth::user();
			$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
			$empresa = \DB::select($sql, [$usuario->id]);
			$empresa = \App\Models\Empresa::findOrFail($empresa[0]->id_empresa);

			$trabajador = \App\Models\Trabajador::findOrFail(\Input::get('id_trabajador'));
			if($trabajador->id_empresa != $empresa->id) $salida = trans('base.trabajador_desconocido');

			$fichaje = \App\Models\Fichaje::findOrFail(\Input::get('id_fichaje'));
			if($fichaje->id_trabajador != $trabajador->id) $salida = trans('base.fichaje_desconocido');

			$inicio = strtotime(str_replace('/', '-', \Input::get('inicio')));
			$fichaje->inicio = date('Y-m-d G:i:s', $inicio);

			$fin = strtotime(str_replace('/', '-', \Input::get('fin')));
			$fichaje->fin = date('Y-m-d G:i:s', $fin);
			$fichaje->save();

		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.fichaje_desconocido');
		}
		return \Response::json($salida);
	}

	public function postEliminarFichaje(){
		$salida = '';
		try {

			$usuario = \Auth::user();
			$sql = 'select id_empresa from usuarios_empresa where id_usuario=?';
			$empresa = \DB::select($sql, [$usuario->id]);
			$empresa = \App\Models\Empresa::findOrFail($empresa[0]->id_empresa);

			$trabajador = \App\Models\Trabajador::findOrFail(\Input::get('id_trabajador'));
			if($trabajador->id_empresa != $empresa->id) $salida = trans('base.trabajador_desconocido');

			$fichaje = \App\Models\Fichaje::findOrFail(\Input::get('id_fichaje'));
			if($fichaje->id_trabajador != $trabajador->id) $salida = trans('base.fichaje_desconocido');

			if($salida == ''){
				$fichaje->delete();
			}

		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.fichaje_desconocido');
		}
		return \Response::json($salida);
	}

}
