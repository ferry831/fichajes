<div class="modal fade" id="nuevoUsuarioEmpresa" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form class="form-horizontal" role="form" method="post" action="<?=(!$perfil_empresa)?\URL::action('Empresas@postNuevoUsuario'):\URL::action('Empresa@postNuevoUsuario')?>" onsubmit="return validar_nuevo_usuario(this)">
        <div class="modal-header">
          <h4 class="modal-title"><?=trans('base.nuevo_usuario')?></h4>
        </div>
        <div class="modal-body">
          <input type="hidden" name="_token" value="<?=csrf_token()?>">
          <input type="hidden" name="id_empresa" value="<?=$empresa->id?>">
          <?

            $inline = true;

            $nombre = 'nombre';
            $label = trans('base.nombre');
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

            $nombre = 'apellidos';
            $label = trans('base.apellidos');
            echo view('ui/input', compact('nombre', 'label', 'inline'));

            $nombre = 'email';
            $label = trans('base.email');
            $validar = 'email';
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido', 'validar'));

            $nombre = 'password';
            $label = trans('base.password');
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

          ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal"><?=trans('base.cerrar')?></button>
          <?=view('ui/submit', ['label' => trans('base.crear_usuario')])?>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  function validar_nuevo_usuario(f){
    if(f.password.value.trim() == ''){ swal('<?=trans('base.error')?>', '<?=trans('configuracion.password_vacio')?>', 'error'); return false; }
    if(f.password.value.trim().length < 5 ){ swal('<?=trans('base.error')?>', '<?=trans('configuracion.password_corto')?>', 'error'); return false; }
    return true;
  }
</script>
