<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;

class Usuario extends Model implements AuthenticatableContract, CanResetPasswordContract {

	use Authenticatable, CanResetPassword;

	protected $table = 'usuarios';
	protected $fillable = ['nombre', 'email', 'password', 'perfil'];
	protected $hidden = ['password', 'remember_token'];

	public function resetToken(){
		do {
			$this->reset_token = md5($this->email.$this->password.time().rand(0, 9999999));
		} while(Usuario::where('reset_token', $this->reset_token)->count() > 0);
		$this->reset_token_time = date('Y-m-d H:i:s');
		$this->save();
		return $this->reset_token;
	}

	public function puede($permisos = array()){

		// comprobar si tiene permiso admin y entonces no hay que mirar mas
		$sql = 'select count(*) as c from permisos_usuario where id_usuario=? and permiso=?';
		$res = \DB::select($sql, [$this->id, 'admin']);
		if($res[0]->c > 0) return true;

		$puede = false;

		// comprobar si tiene alguno de los permisos solicitados
		if(!is_array($permisos)) $permisos = array($permisos);
		foreach($permisos as $permiso){
			$sql = 'select count(*) as c from permisos_usuario where id_usuario=? and permiso=?';
			$res = \DB::select($sql, [$this->id, $permiso]);
			$puede = $puede || ($res[0]->c > 0);
		}

		return $puede;

	}

	public function setPermiso($permiso){

		if($permiso == 'admin'){
			// si el usuario va a ser admin le sobran el resto de permisos
			$sql = 'delete from permisos_usuario where id_usuario = ?';
			\DB::delete($sql, [$this->id]);
		}

		if(!$this->puede('admin')){
			// si el usuario ya es admin le sobra todo lo demás
			$sql = 'insert ignore permisos_usuario (id_usuario, permiso) values (?, ?)';
			\DB::insert($sql, [$this->id, $permiso]);
		}

	}

	public function unsetPermiso($permiso){
		$sql = 'delete from permisos_usuario where id_usuario = ? and permiso = ?';
		\DB::delete($sql, [$this->id, $permiso]);
	}

	public function log_inicio_sesion($error = ''){
		$sql = 'insert into log_inicio_sesion (id_usuario, nombre, apellidos, email, ip, error, created_at) values (?, ?, ?, ?, ?, ?, now())';
		\DB::insert($sql, [$this->id, $this->nombre, $this->apellidos, $this->email, $_SERVER['REMOTE_ADDR'], $error]);
	}

}
