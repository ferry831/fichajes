<?php

	if(!isset($menu)) $menu = '';
	if(!isset($submenu)) $submenu = '';

	$usuario = Auth::user();

	$items = array(
		['id' => 'inicio', 'ico' => 'md-home', 'label' => 'base.inicio', 'href' => \URL::route('inicio')],
	);

	if($usuario->perfil == 'administrador'){

		$items[] = ['id' => 'empresas', 'ico' => 'md-store', 'label' => 'base.gestion_empresas', 'href' => \URL::action('Empresas@getIndex')];

		if($usuario->puede('gestion_usuarios')){
			$configuracion = ['id' => 'configuracion', 'ico' => 'md-settings', 'label' => 'configuracion.configuracion', 'items' => []];
			if($usuario->puede('gestion_usuarios'))
				$configuracion['items'][] = ['id' => 'usuarios', 'label' => 'configuracion.gestion_usuarios', 'href' => \URL::action('Configuracion\Usuarios@getIndex')];
			$items[] = $configuracion;
		}

	}

	if($usuario->perfil == 'empresa'){

		$items[] = ['id' => 'empresas', 'ico' => 'md-store', 'label' => 'base.ficha_empresa', 'href' => \URL::action('Empresa@getIndex')];
		$items[] = ['id' => 'trabajadores', 'ico' => 'md-people', 'label' => 'base.gestion_trabajadores', 'href' => \URL::action('Trabajadores@getIndex')];
		$items[] = ['id' => 'informe', 'ico' => 'md-assignment', 'label' => 'base.informe_fichajes', 'href' => \URL::action('Informes@getFichajes')];

	}

  // pintamos el menu

	foreach($items as $item){
		if(!isset($item['href'])) $item['href'] = '';
		$es_submenu = (isset($item['items']) && is_array($item['items']));
    ?>
      <li class="<? if($es_submenu) echo 'sub-menu '; if($menu == $item['id']) echo 'active '; ?>">
      	<a href="<?=$item['href']?>"><i class="md <?=$item['ico']?>"></i> <?=trans($item['label'])?></a>
      	<? if($es_submenu){ ?>
      	<ul>
      		<? foreach($item['items'] as $subitem){ ?>
          <li><a <? if($submenu == $subitem['id']) echo 'class="active"'; ?> href="<?=$subitem['href']?>"><?=trans($subitem['label'])?></a></li>
          <? } ?>
        </ul>
      	<? } ?>
      </li>
    <?
  }
