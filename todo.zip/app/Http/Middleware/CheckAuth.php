<?php namespace App\Http\Middleware;

use Closure;
use Auth;

class CheckAuth {

	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @return mixed
	 */
	public function handle($request, Closure $next){

		// si no está logueado, ir al inicio de sesión
		if(!Auth::check() && !Auth::viaRemember()){
			return \Redirect::action('Login@getIndex');
		}

		// comprobar que no se le ha retirado el permiso de inicio de sesion, y en tal caso, al inicio de sesión
		$usuario = Auth::user();
		if(!$usuario->puede('inicio_sesion')){
			Auth::logout();
			return \Redirect::action('Login@getIndex');
		}

		// comprobamos si la ruta depende de un controlador y si este tiene perfil y permisos definidos
		$accion = $request->route()->getAction();
		if(isset($accion['controller'])){
			$controller = explode('@', $accion['controller'])[0];
			$perfiles = (isset($controller::$perfiles)) ? $controller::$perfiles : [] ;
			if(is_array($perfiles) && count($perfiles) > 0){
				if(!in_array($usuario->perfil, $perfiles)){
					\Session::put('error', trans('permisos.sin_permiso'));
					return \Redirect::to('/');
				}
			}
			$permisos = (isset($controller::$permisos)) ? $controller::$permisos : [] ;
			if(is_array($permisos) && count($permisos) > 0){
				if(!$usuario->puede($permisos)){
					\Session::put('error', trans('permisos.sin_permiso'));
					return \Redirect::to('/');
				}
			}
		}

		return $next($request);
	}

}
