<?php

	// aquí se definen todos los perfiles posibles.
	// el permiso se define por la clave del array, el valor es meramente descriptivo
	// de hecho no se utiliza para nada, el texto mostrado en la gestión de usuarios se obtiene del fichero de idioma 'perfiles.php'

	return array(

		'administrador' => 'administrador',
		'empresa' => 'empresa',

	);
