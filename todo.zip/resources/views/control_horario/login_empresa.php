<div class="col-sm-6 col-sm-push-3 p-t-0">

	<div class="card">
		<form id="login_empresa" name="login_empresa" method="POST" action="<?=\URL::action('ControlHorario@postLoginEmpresa')?>" class="form-horizontal">
			<div class="card-header bgm-bluegray">
				<h2><?=trans('base.inicio_sesion_empresa')?></h2>
			</div>
			<div class="card-body card-padding">
				<input type="hidden" name="_token" value="<?=csrf_token()?>">
				<?

					$nombre = 'cif';
					$label = trans('base.cif');
					$requerido = true;
					$inline = true;
					echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

					$nombre = 'pin';
					$label = trans('base.pin');
					$tipo = 'password';
					echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido', 'tipo'));

					echo view('ui/submit', ['clases' => ['col-sm-push-3'], 'label' => trans('base.iniciar_sesion')]);

				?>
			</div>
		</form>
	</div>

</div>
