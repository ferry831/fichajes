<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
class Aviso extends Model {
	protected $table = 'avisos';
	public $timestamps = false;

	public function enviar(){
		$trabajador = Trabajador::find($this->id_trabajador);
		if($trabajador->email != ''){
			\Mail::send('trabajadores/email_aviso', [], function($message) use ($trabajador){
				$message->subject(trans('base.asunto_email_aviso'));
				$message->to($trabajador->email);
			});
		}
	}

}
