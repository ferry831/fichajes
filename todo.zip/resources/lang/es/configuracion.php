<?php

	return array(

    'configuracion' => 'Configuración',

    'gestion_usuarios' => 'Gestión de usuarios',
		'listado_usuarios' => 'Listado de usuarios',
		'nuevo_usuario' => 'Nuevo usuario',
		'crear_usuario' => 'Crear usuario',

		'nombre' => 'Nombre',
		'apellidos' => 'Apellidos',
		'email' => 'Email',
		'perfil' => 'Perfil',
		'password' => 'Contraseña',

		'nombre_vacio' => 'El nombre no puede estar en blanco',
		'email_vacio' => 'El correo electrónico no puede estar en blanco',
		'email_invalido' => 'El correo electrónico no es valido',
		'password_vacio' => 'La contraseña no puede estar en blanco',
		'password_corto' => 'La contraseña es demasiado corta',

		'usuario_existe' => 'Ya existe otro usuario con ese correo electrónico',
		'usuario_creado' => 'Usuario creado con éxito',
		'error_creando_usuario' => 'Ha ocurrido un error creando el usuario',

		'borrar_usuario' => 'Eliminar usuario',
		'usuario_eliminado' => 'El usuario ha sido eliminado',
		'imposible_eliminar' => 'No ha sido posible eliminar al usuario',
		'usuario_desconocido' => 'Usuario desconocido',

		'ficha_usuario' => 'Ficha de usuario',

		'datos_personales' => 'Datos personales',
		'permisos_usuario' => 'Permisos',
		'cambiar_password' => 'Cambiar contraseña',
		'repetir_password' => 'Repite tu nueva contraseña',
		'repetir_password_vacio' => 'Debes repetir tu nueva contraseña',
		'password_no_coincide' => 'Las contraseñas no coinciden',
		'cambiar_password' => 'Cambiar contraseña',
		'password_cambiado' => 'Contraseña cambiada',

	);
