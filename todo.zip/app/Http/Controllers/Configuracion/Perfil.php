<?php

namespace App\Http\Controllers\Configuracion;
use App\Http\Controllers\Controller;

class Perfil extends Controller {

	public static $permisos = [];

	public function getIndex(){

		try {

			$usuario = \Auth::user();
			$params = [
				'contenido' => view('configuracion/perfil/info', compact('usuario')),
			];
			return view('plantilla', $params);

		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			\Session::put('error', trans('configuracion.usuario_desconocido'));
			return \Redirect::route('inicio');
		}

	}

	public function postInfo(){
		$salida = '';
		try {

			$usuario = \Auth::user();
			switch(\Input::get('operacion')){

				case 'datos_personales':
					$sql = 'select id from usuarios where email=? and id<>?';
					$res = \DB::select($sql, [\Input::get('email'), $usuario->id]);
					if(count($res) == 0){
						$usuario->email = \Input::get('email');
						$usuario->nombre = \Input::get('nombre');
						$usuario->apellidos = \Input::get('apellidos');
						$usuario->save();
					} else {
						$salida = trans('configuracion.usuario_existe');
					}
				break;

				case 'cambiar_password':
					$usuario->password = bcrypt(\Input::get('password'));
					$usuario->save();
				break;

			}

		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('configuracion.usuario_desconocido');
		}
		return \Response::json($salida);
	}

}
