<div class="modal fade" id="nuevaEmpresa" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form class="form-horizontal" role="form" method="post" action="<?=\URL::action('Empresas@postNuevaEmpresa')?>" onsubmit="return validar_nueva_empresa(this)">
        <div class="modal-header">
          <h4 class="modal-title"><?=trans('base.nueva_empresa')?></h4>
        </div>
        <div class="modal-body">
          <input type="hidden" name="_token" value="<?=csrf_token()?>">
					<p class="f-700"><?=trans('base.datos_empresa')?></p>
          <?

            $inline = true;

            $nombre = 'razon_social';
            $label = trans('base.razon_social');
            $requerido = true;
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

            $nombre = 'cif';
            $label = trans('base.cif');
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

						$nombre = 'centro_trabajo';
            $label = trans('base.centro_trabajo');
            echo view('ui/input', compact('nombre', 'label', 'inline'));

						$nombre = 'ccc';
            $label = trans('base.ccc');
            echo view('ui/input', compact('nombre', 'label', 'inline'));

					?>
					<p class="f-700"><?=trans('base.datos_usuario')?></p>
					<?

            $nombre = 'email';
            $label = trans('configuracion.email');
            $validar = 'email';
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido', 'validar'));

            $nombre = 'password';
            $label = trans('configuracion.password');
            echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

          ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal"><?=trans('base.cerrar')?></button>
          <?=view('ui/submit', ['label' => trans('base.crear_empresa')])?>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  function validar_nueva_empresa(f){
    if(f.password.value.trim() == ''){ swal('<?=trans('base.error')?>', '<?=trans('configuracion.password_vacio')?>', 'error'); return false; }
    if(f.password.value.trim().length < 5 ){ swal('<?=trans('base.error')?>', '<?=trans('configuracion.password_corto')?>', 'error'); return false; }
    return true;
  }
</script>
