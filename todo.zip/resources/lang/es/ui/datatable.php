<?php

	return array(
		'all' => 'Todos',
		'infos' => 'Mostrando entradas {{ctx.start}} a {{ctx.end}} de un total de {{ctx.total}}',
		'loading' => 'Cargando...',
		'noResults' => 'No hay registros',
		'refresh' => 'Recargar',
		'search' => 'Buscar',
	);
