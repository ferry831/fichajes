<div class="block-header">
  <h2><?=trans('base.mi_perfil')?></h2>
</div>

<div class="col-sm-6">

  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('configuracion.datos_personales')?></h2>
    </div>
    <div class="card-body card-padding">
      <form id="datos_personales" name="datos_personales" method="POST" ajax="true" action="<?=\URL::action('Configuracion\Perfil@postInfo')?>">
        <input type="hidden" name="operacion" value="datos_personales">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">
        <?

          $nombre = 'nombre';
          $label = trans('configuracion.nombre');
          $valor = $usuario->nombre;
          $requerido = true;
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido'));

          $nombre = 'apellidos';
          $label = trans('configuracion.apellidos');
          $valor = $usuario->apellidos;
          $requerido = false;
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido'));

          $nombre = 'email';
          $label = trans('configuracion.email');
          $valor = $usuario->email;
          $requerido = true;
          $validar = 'email';
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido', 'validar'));

          echo view('ui/submit');

        ?>
      </form>
    </div>
  </div>

</div>

<div class="col-sm-6">

  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('configuracion.cambiar_password')?></h2>
    </div>
    <div class="card-body card-padding">
      <form id="cambiar_password" name="cambiar_password" method="POST" ajax="<?=htmlentities(trans('configuracion.password_cambiado'))?>" action="<?=\URL::action('Configuracion\Perfil@postInfo')?>" onsubmit="return validar_password(this)">
        <input type="hidden" name="operacion" value="cambiar_password">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">
        <?

          $tipo = 'password';
          $nombre = 'password';
          $label = trans('configuracion.password');
          $requerido = true;
          echo view('ui/input', compact('tipo', 'nombre', 'label', 'requerido'));

          $nombre = 'repetir_password';
          $label = trans('configuracion.repetir_password');
          $requerido = true;
          echo view('ui/input', compact('tipo', 'nombre', 'label', 'requerido'));

          echo view('ui/submit', ['label' => trans('configuracion.cambiar_password')]);

        ?>
      </form>
    </div>
  </div>

  <script>
    function validar_password(f){
      if(f.password.value.trim().length < 5 ){ swal('<?=trans('base.error')?>', '<?=trans('configuracion.password_corto')?>', 'error'); return false; }
      if(f.password.value.trim() != f.repetir_password.value.trim()){ swal('<?=trans('base.error')?>', '<?=trans('configuracion.password_no_coincide')?>', 'error'); return false; }
      return true;
    }
  </script>

</div>
