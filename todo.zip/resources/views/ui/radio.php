<?php

  if(!isset($id)) 				$id = 'input-'.md5(microtime().rand(0, 999999));
	if(!isset($nombre)) 		$nombre = '';
  if(!isset($label)) 		  $label = '';
  if(!isset($campo)) 			$campo = '';
	if(!isset($valor)) 			$valor = '';
	if(!isset($requerido)) 	$requerido = false; // o true o texto de validacion
	if(!isset($inline))			$inline = false;
  if(!isset($opciones))   $opciones = [];

  if($campo == '') $campo = $label;

?>
<div class="form-group">
  <? if($label != ''){ ?><label class="control-label <?=($inline)?'col-sm-3':''?>" for="<?=htmlentities($id)?>"><?=$label?></label><? } ?>
  <fieldset class="radio <?=($inline)?'col-sm-9':''?>" id="<?=htmlentities($id)?>" campo="<?=htmlentities($campo)?>"
    <? if($requerido !== false)   echo 'requerido="si" '; ?>
    <? if(is_string($requerido))	echo 'texto-requerido="'.htmlentities($requerido).'" '?>>
    <?
      foreach($opciones as $opcion){
        if(!is_array($opcion)) $opcion = ['valor' => $opcion];
        if(!isset($opcion['valor'])) $opcion['valor'] = '';
        if(!isset($opcion['label'])) $opcion['label'] = $opcion['valor'];
        if(!isset($opcion['disabled'])) $opcion['disabled'] = false;
        $opcion['id'] = $id.'-'.md5(print_r($opcion, true));
    ?>
    <div class="radio <?=($opcion['disabled'])?'disabled':''?>">
      <label for="<?=htmlentities($opcion['id'])?>">
        <input id="<?=htmlentities($opcion['id'])?>" type="radio" name="<?=htmlentities($nombre)?>" value="<?=htmlentities($opcion['valor'])?>" <?=($opcion['disabled'])?'disabled="disabled"':''?> <?=($valor == $opcion['valor'])?'checked="checked"':''?>>
          <i class="input-helper"></i>
          <?=$opcion['label']?>
      </label>
      <div class="clearfix"></div>
    </div>
    <? } ?>
  </fieldset>
</div>
