<?php
  if(!isset($id))         $id = 'dt-'.md5(microtime().rand(0, 999999));
  if(!isset($titulo))     $titulo = '';
  if(!isset($subtitulo))  $subtitulo = '';
  if(!isset($selector))   $selector = false;
  if(!isset($formatters)) $formatters = [];
  if(!isset($columnas))   $columnas = [];
?>

<div class="card">
  <? if($titulo != '' || $subtitulo != ''){ ?>
  <div class="card-header">
    <h2><?=$titulo?><small><?=$subtitulo?></small></h2>
  </div>
  <? } ?>
  <div class="table-responsive">
    <table id="<?=$id?>" class="table table-striped">
      <thead>
        <tr>
          <?
            foreach($columnas as $c){
              if(!isset($c['visible'])) $c['visible'] = true;
              if(!isset($c['sortable'])) $c['sortable'] = false;
              if(!isset($c['searchable'])) $c['searchable'] = false;
              if(!isset($c['identifier'])) $c['identifier'] = false;
              if(!isset($c['formatter'])) $c['formatter'] = '';
              if(!isset($c['order'])) $c['order'] = '';
              if(!isset($c['align'])) $c['align'] = '';
          ?>
          <th data-column-id="<?=$c['id']?>" data-visible="<?=($c['visible'])?'true':'false'?>" data-sortable="<?=($c['sortable'])?'true':'false'?>" data-searchable="<?=($c['searchable'])?'true':'false'?>" data-identifier="<?=($c['identifier'])?'true':'false'?>" data-formatter="<?=$c['formatter']?>" data-order="<?=$c['order']?>" data-align="<?=$c['align']?>"><?=$c['label']?></th>
          <? } ?>
        </tr>
      </thead>
      <tbody>
      </tbody>
    </table>
  </div>
</div>

<? if(isset($url)){ ?>
<script>
  $('document').ready(function(){
    $("table#<?=$id?>").bootgrid({
      ajax: true,
      url: '<?=$url?>',
      css: {
        icon: 'md icon',
        iconColumns: 'md-view-module',
        iconDown: 'md-expand-more',
        iconRefresh: 'md-refresh',
        iconUp: 'md-expand-less'
      },
      searchSettings: {
        delay: 500
      },
      post: function (){
        return { _token: "<?=csrf_token()?>" };
      },
      columnSelection: false,
      selection: <?=$selector?'true':'false'?>,
      multiSelect: <?=$selector?'true':'false'?>,
      keepSelection: <?=$selector?'true':'false'?>,
      labels: {
        all: '<?=trans('ui/datatable.all')?>',
        infos: '<?=trans('ui/datatable.infos')?>',
        loading: '<?=trans('ui/datatable.loading')?>',
        noResults: '<?=trans('ui/datatable.noResults')?>',
        refresh: '<?=trans('ui/datatable.refresh')?>',
        search: '<?=trans('ui/datatable.search')?>',
      },
      <? if(count($formatters) > 0){ ?>
      formatters: {
        <? foreach($formatters as $f => $fn){ ?>
        '<?=$f?>': function(column, row){ <?=$fn?> },
        <? } ?>
      }
      <? } ?>
    });
  });
</script>
<? } ?>
