<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
class Fichaje extends Model {
	protected $table = 'fichajes';
	public $timestamps = false;

	static function cerrarAbiertos(){

		$sql = 'select f.id, f.id_trabajador, f.inicio, ifnull(t.hora_cierre, e.hora_cierre) as hora_cierre, t.horas, t.intervalo from fichajes f left join trabajadores t on f.id_trabajador = t.id left join empresas e on t.id_empresa = e.id where f.fin is null and time(f.inicio) < ifnull(t.hora_cierre, e.hora_cierre) and ifnull(t.hora_cierre, e.hora_cierre) < time(now())';
		$fichajes = \DB::select($sql);
		foreach($fichajes as $fichaje){

			// calculamos las horas de fichajes cerrados de ese mismo dia para ese trabajador
			$tiempo_hoy = 0;
			$inicio = strtotime('00:00', strtotime($fichaje->inicio));
			$sql = 'select inicio, fin from fichajes where id_trabajador = ? and inicio >= ? and not fin is null';
			$params = [$fichaje->id_trabajador, date('Y-m-d H:i:s', $inicio)];
			$hoy = \DB::select($sql, $params);
			foreach($hoy as $f) $tiempo_hoy += strtotime($f->fin) - strtotime($f->inicio);

			// calculamos la duración de las jornadas de los 15 dias anteriores para ese trabajador
			$jornadas_anteriores = [];
			for($i=1; $i<=15; $i++){
				$fecha = strtotime('-'.$i.' days', $inicio);
				$sql = 'select inicio, fin from fichajes where id_trabajador = ? and inicio >= ? and not fin is null';
				$params = [$fichaje->id_trabajador, date('Y-m-d H:i:s', $fecha)];
				$jornada = 0;
				$fichajes_anteriores = \DB::select($sql, $params);
				foreach($fichajes_anteriores as $f) $jornada += strtotime($f->fin) - strtotime($f->inicio);
				if($jornada > 0) $jornadas_anteriores[] = $jornada;
			}

			// calculamos la duración de la jornada media para cada trabajador
			$jornada_media = 0;
			if(count($jornadas_anteriores) > 0) $jornada_media = array_sum($jornadas_anteriores) / count($jornadas_anteriores);
			else {
				switch($fichaje->intervalo){
					case 'dia': $jornada_media = $fichaje->horas; break;
					case 'semana': $jornada_media = $fichaje->horas / 7; break;
					case 'mes': $jornada_media = $fichaje->horas / 30; break;
					case 'año': $jornada_media = $fichaje->horas / 365; break;
				}
				$jornada_media = $jornada_media * 60 * 60; // horas a segundos
			}

			$diferencia = $jornada_media - $tiempo_hoy;
			$diferencia += $diferencia * rand(-10, 10) / 1000;

			if($diferencia > 0){
				$sql = 'update fichajes set fin=? where id=?';
				$params = [date('Y-m-d H:i:s', strtotime($fichaje->inicio) + floor($diferencia)), $fichaje->id];
				\DB::update($sql, $params);
			}

		}
	}

	public function duracion(){

		$inicio = strtotime($this->inicio);
		$fin = is_null($this->fin) ? time() : strtotime($this->fin);

		$segundos = $fin - $inicio;

		$minutos = floor($segundos / 60);
		$segundos = $segundos - ($minutos * 60);

		$horas = floor($minutos/ 60);
		$minutos = $minutos - ($horas * 60);

		$output = [];
		if($horas > 0){
			$output[] = $horas.'h';
		}
		if(count($output) > 0 || $minutos > 0){
			$output[] = $minutos.'m';
		}
		
		//$output[] = $segundos.'s';

		return join(' ', $output);

	}

}
