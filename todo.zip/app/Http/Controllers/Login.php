<?php namespace App\Http\Controllers;

class Login extends Controller {

	public function __construct(){
    $this->middleware('noAuth', ['except' => ['getLogout']]);
  }

	public function getIndex(){
		return view('login/login');
	}

	public function postLogin(){
		if(\Auth::attempt(['email' => \Input::get('usuario'), 'password' => \Input::get('password')], \Input::has('recuerdame'))){
			$usuario = \Auth::user();
			if(!$usuario->puede('inicio_sesion')){
				$usuario->log_inicio_sesion('sin_permisos');
				\Auth::logout();
				\Session::put('error', trans('login.login_prohibido'));
				return \Redirect::action('Login@getIndex');
			} else {
				$usuario->log_inicio_sesion();
      	return redirect()->intended('/');
      }
      return \Redirect::route('inicio');
    } else {
			$usuario = \App\Models\Usuario::where('email', \Input::get('usuario'))->first();
			if(!is_null($usuario)) $usuario->log_inicio_sesion('auth_incorrecto');
			\Session::put('error', trans('login.login_incorrecto'));
			return \Redirect::action('Login@getIndex');
		}
	}

	public function getOlvido(){
		return view('login/olvido');
	}

	public function postOlvido(){
		if($usuario = \App\Models\Usuario::where('email', \Input::get('email'))->first()){
			$token = $usuario->resetToken();
			\Mail::send('login/email_reset', ['token' => $token, 'email' => $usuario->email], function($message) use ($usuario){
    		$message->subject(trans('login.asunto_reset_email'));
    		$message->to($usuario->email);
				//$message->to('vicente@microvalencia.es');
			});
		}
		\Session::put('success', trans('login.instrucciones_enviadas'));
		return \Redirect::action('Login@getIndex');
	}

	public function getReset($token = ''){
		if($usuario = \App\Models\Usuario::where('reset_token', $token)->first()){
			return view('login/reset', compact('token', 'usuario'));
		}
		\Session::put('error', trans('login.token_incorrecto'));
		return \Redirect::action('Login@getOlvido');
	}

	public function postReset(){
		if($usuario = \App\Models\Usuario::where('reset_token', \Input::get('token'))->first()){
			$usuario->password = bcrypt(\Input::get('password'));
			$usuario->reset_token = null;
			$usuario->reset_token_time = null;
			$usuario->save();
			\Session::put('success', trans('login.password_reiniciado'));
		}
		return \Redirect::action('Login@getIndex');
	}

	public function getLogout(){
		\Auth::logout();
		return \Redirect::action('Login@getIndex');
	}

}
