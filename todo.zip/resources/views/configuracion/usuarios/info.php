<? $auth = \Auth::user(); ?>

<div class="block-header">
  <h2><?=trans('configuracion.ficha_usuario')?></h2>
  <div class="actions">
    <button class="btn btn-default waves-effect" onclick="document.location.href='<?=\URL::action('Configuracion\Usuarios@getIndex')?>'"><?=trans('configuracion.listado_usuarios')?></button>
    <? if($auth->id != $usuario->id){ ?><button class="btn btn-danger waves-effect" onclick="eliminar()"><?=trans('configuracion.borrar_usuario')?></button><? } ?>
    <button class="btn btn-primary waves-effect" data-toggle="modal" href="#nuevoUsuario"><?=trans('configuracion.nuevo_usuario')?></button>
  </div>
</div>
<?=view('configuracion/usuarios/nuevo_usuario')?>

<? if($auth->id != $usuario->id){ ?>
<script>
  function eliminar(){
    swal({
      title: "<?=trans('base.estas_seguro')?>",
      text: "<?=trans('base.no_undo')?>",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#DD6B55",
      confirmButtonText: "<?=trans('base.si')?>",
      cancelButtonText: "<?=trans('base.no')?>",
      closeOnConfirm: false
    }, function(){
      $.post(
        '<?=\URL::action('Configuracion\Usuarios@postEliminar')?>',
        {id: <?=$usuario->id?>, _token: '<?=csrf_token()?>'},
        function(r){
          if(r != "") swal("<?=trans('base.error')?>", r, "error");
          else document.location.href = '<?=\URL::action('Configuracion\Usuarios@getIndex')?>';
        }
      );
    });
  }
</script>
<? } ?>

<div class="col-sm-6">

  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('configuracion.datos_personales')?></h2>
    </div>
    <div class="card-body card-padding">
      <form id="datos_personales" name="datos_personales" method="POST" ajax="true" action="<?=\URL::action('Configuracion\Usuarios@postInfo')?>">

        <input type="hidden" name="id" value="<?=$usuario->id?>">
        <input type="hidden" name="operacion" value="datos_personales">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">

        <?

          $nombre = 'nombre';
          $label = trans('configuracion.nombre');
          $valor = $usuario->nombre;
          $requerido = true;
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido'));

          $nombre = 'apellidos';
          $label = trans('configuracion.apellidos');
          $valor = $usuario->apellidos;
          echo view('ui/input', compact('nombre', 'label', 'valor'));

          $nombre = 'email';
          $label = trans('configuracion.email');
          $valor = $usuario->email;
          $validar = 'email';
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido', 'email'));

          /*
          $perfiles = \Config::get('perfiles');
          if(count($perfiles) > 0){
            $nombre = 'perfil';
            $label = trans('configuracion.perfil');
            $opciones = array();
            foreach($perfiles as $perfil){
              $opciones[] = array('label' => trans('perfiles.'.$perfil), 'valor' => $perfil);
            }
            $valor = $usuario->perfil;
            echo view('ui/select', compact('nombre', 'label', 'inline', 'requerido', 'opciones', 'valor'));
          }
          */

          echo view('ui/submit');

        ?>

      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('configuracion.cambiar_password')?></h2>
    </div>
    <div class="card-body card-padding">
      <form id="cambiar_password" name="cambiar_password" method="POST" ajax="<?=htmlentities(trans('configuracion.password_cambiado'))?>" action="<?=\URL::action('Configuracion\Usuarios@postInfo')?>" onsubmit="return validar_password(this)">
        <input type="hidden" name="id" value="<?=$usuario->id?>">
        <input type="hidden" name="operacion" value="cambiar_password">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">
        <?

          $tipo = 'password';
          $nombre = 'password';
          $label = trans('configuracion.password');
          $requerido = true;
          echo view('ui/input', compact('tipo', 'nombre', 'label', 'requerido'));

          $nombre = 'repetir_password';
          $label = trans('configuracion.repetir_password');
          echo view('ui/input', compact('tipo', 'nombre', 'label', 'requerido'));

          echo view('ui/submit', ['label' => trans('configuracion.cambiar_password')]);

        ?>
      </form>
    </div>
  </div>

  <script>
    function validar_password(f){
      if(f.repetir_password.value.trim() == ''){ swal('<?=trans('base.error')?>', '<?=trans('configuracion.repetir_password_vacio')?>', 'error'); return false; }
      if(f.password.value.trim() != f.repetir_password.value.trim()){ swal('<?=trans('base.error')?>', '<?=trans('configuracion.password_no_coincide')?>', 'error'); return false; }
      return true;
    }
  </script>

</div>

<div class="col-sm-6">

  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('configuracion.permisos_usuario')?></h2>
    </div>
    <form id="permisos" name="permisos" method="POST" ajax="true" onajax="cargar_permisos();" action="<?=\URL::action('Configuracion\Usuarios@postPermisos')?>">

      <input type="hidden" name="id" value="<?=$usuario->id?>">
      <input type="hidden" name="_token" value="<?=csrf_token()?>">

      <div class="table-responsive m-t-15" tabindex="4" style="overflow: hidden; outline: none;">

        <?php
          $permisos = Config::get('permisos.lista');
          foreach($permisos as $seccion => $lista){
        ?>
        <table class="table table-condensed permisos">
          <thead>
            <tr><th><?=trans('permisos.'.$seccion)?></th></tr>
          </thead>
          <tbody>
            <tr><td>
            <?
              foreach($lista as $permiso => $descripcion){
                $id = 'permiso_'.$permiso;
                $nombre = 'permiso_'.$permiso;
                $checked = $usuario->puede($permiso);
                $label = trans('permisos.'.$permiso);
                $clases = ['m-b-15'];
                echo view('ui/checkbox', compact('id', 'nombre', 'checked', 'label', 'clases'));
              }
            ?>
            </td></tr>
          </tbody>
        </table>
        <? } ?>
      </div>
      <?=view('ui/submit', ['clases' => ['m-l-25', 'm-b-25', 'm-t-30']])?>
    </form>
  </div>

  <script>
    function cargar_permisos(){
      $.get(
        '<?=\URL::action('Configuracion\Usuarios@getPermisos', [$usuario->id])?>',
        function(data){
          for(var key in data){
            $('#permiso_' + key).prop('checked', data[key]);
          }
        }
      );
    }
  </script>

</div>
