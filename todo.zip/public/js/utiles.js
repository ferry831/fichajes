String.prototype.trim = function(){ return this.replace(/^\s+|\s+$/g,'') }

function validar_email(email){
	var emailRegEx = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
	if(email.search(emailRegEx) == -1) return false;
	else return true;
}

function validar_decimal(decimal){
	var decimalRegEx = /^([\+-])?([0-9])*[.]?[0-9]*$/i;
	if(decimal.search(decimalRegEx) == -1) return false;
	else return true;
}

function validar_entero(entero){
	var enteroRegEx = /^([\+-])?([0-9])*$/i;
	if(entero.search(enteroRegEx) == -1) return false;
	else return true;
}

function validar_fecha(fecha){
	var fechaRegEx = /^\d{2}\/\d{2}\/\d{4}$/;
  if((fecha.match(fechaRegEx)) && (fecha != '') && existe_fecha(fecha)) return true;
  else return false;
}
function validar_hora(hora){
	var horaRegEx = /^\d{2}:\d{2}$/;
	if((hora.match(horaRegEx)) && (hora != '') && existe_hora(hora)) return true;
  else return false;
}

function existe_fecha(fecha) {
  var fecha = fecha.split("/");
  var d = parseInt(fecha[0]); var m = parseInt(fecha[1]) - 1; var a = parseInt(fecha[2]);
  var fecha = new Date(a, m, d);
  return d == fecha.getDate() && m == fecha.getMonth() && a == fecha.getFullYear();
}

function existe_hora(hora){
	var hora = hora.split(":");
	var h = parseInt(hora[0]);
	var m = parseInt(hora[1]);
	if(h >= 0 && h < 24 && m >= 0 && m < 60) return true;
	else return false;
}

function validar_fecha_hora(fecha){
	var fechaRegEx = /^\d{2}\/\d{2}\/\d{4}\s\d{2}:\d{2}$/;
  if((fecha.match(fechaRegEx)) && (fecha != '')){
  	fecha = fecha.split(' ');
  	if(validar_fecha(fecha[0]) && validar_hora(fecha[1])) return true;
  }
  return false;
}

function slugify(text){
  return text.toString().toLowerCase()
    .replace(/\s+/g, '-')           // Replace spaces with -
    .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
    .replace(/\-\-+/g, '-')         // Replace multiple - with single -
    .replace(/^-+/, '')             // Trim - from start of text
    .replace(/-+$/, '');            // Trim - from end of text
}

function slugify_filename(text){
  return text.toString().toLowerCase()
    .replace(/\s+/g, '_')           // Replace spaces with -
    .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
    .replace(/\-\-+/g, '_')         // Replace multiple - with single -
    .replace(/^-+/, '')             // Trim - from start of text
    .replace(/-+$/, '');            // Trim - from end of text
}

$.fn.serializeObject = function(){
  var o = {};
  var a = this.serializeArray();
  $.each(a, function() {
    if (o[this.name] !== undefined) {
      if (!o[this.name].push) {
        o[this.name] = [o[this.name]];
      }
      o[this.name].push(this.value || '');
    } else {
      o[this.name] = this.value || '';
    }
  });
  return o;
};
