<div class="col-sm-6 col-sm-push-3 p-t-0">

	<? if(file_exists('logo/'.strtolower(trim($empresa->logo)))){ ?>
	<div class="text-center m-b-20"><img src="<?=asset('logo/'.strtolower(trim($empresa->logo)))?>" style="max-width: 100%"></div>
	<? } ?>

	<div class="card">
		<form id="login_trabajador" name="login_trabajador" method="POST" action="<?=\URL::action('ControlHorario@postLoginTrabajador')?>" class="form-horizontal">
			<div class="card-header bgm-bluegray">
				<h2>
					<?=trans('base.inicio_sesion_trabajador')?>
					<?=$empresa->razon_social != '' ? '<small>'.$empresa->razon_social.'</small>' : ''?>
				</h2>
			</div>
			<div class="card-body card-padding">
				<input type="hidden" name="_token" value="<?=csrf_token()?>">
				<?

					$nombre = 'nif';
					$label = trans('base.nif');
					$requerido = true;
					$inline = true;
					echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido'));

					$nombre = 'pin';
					$label = trans('base.pin');
					$tipo = 'password';
					echo view('ui/input', compact('nombre', 'label', 'inline', 'requerido', 'tipo'));

					echo view('ui/submit', ['clases' => ['col-sm-push-3'], 'label' => trans('base.iniciar_fichaje')]);

				?>
			</div>
		</form>
	</div>

</div>
