<?php

  return [

    // cabecera
    'toggle_menu' => false,
    'toggled_menu' => true,
    'buscar' => false,
    'panel_derecho' => false,
    'menu_superior' => false, // 'ui/menu_superior',
    'menu_lateral' => 'ui/menu_lateral',
    'footer' => false, // 'ui/footer',

  ];
