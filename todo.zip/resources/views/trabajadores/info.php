<div class="block-header">
  <h2><?=trans('base.ficha_trabajador')?></h2>
  <div class="actions">
    <button class="btn btn-default waves-effect" onclick="document.location.href='<?=\URL::action('Trabajadores@getIndex')?>'"><?=trans('base.listado_trabajadores')?></button>
    <button class="btn btn-danger waves-effect" onclick="eliminar()"><?=trans('base.borrar_trabajador')?></button>
    <button class="btn btn-primary waves-effect" data-toggle="modal" href="#nuevoTrabajador"><?=trans('base.nuevo_trabajador')?></button>
  </div>
</div>
<?=view('trabajadores/nuevo')?>
<?=view('trabajadores/editar_fin_fichaje', compact('trabajador'))?>

<script>
  function eliminar(){
    swal({
      title: "<?=trans('base.estas_seguro')?>",
      text: "<?=trans('base.no_undo')?>",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#DD6B55",
      confirmButtonText: "<?=trans('base.si')?>",
      cancelButtonText: "<?=trans('base.no')?>",
      closeOnConfirm: false
    }, function(){
      $.post(
        '<?=\URL::action('Trabajadores@postEliminar')?>',
        {id: <?=$trabajador->id?>, _token: '<?=csrf_token()?>'},
        function(r){
          if(r != "") swal("<?=trans('base.error')?>", r, "error");
          else document.location.href = '<?=\URL::action('Trabajadores@getIndex')?>';
        }
      );
    });
  }
</script>

<div class="col-sm-12">
  <?php

    // datatable

  	$id = 'listado_fichajes';
  	$titulo = trans('base.listado_fichajes');
  	$url = \URL::action('Trabajadores@postListadoFichajes', [$trabajador->id]);
    $columnas = [
      ['id' => 'id', 'label' => '', 'visible' => false, 'identifier' => true],
      ['id' => 'inicio', 'label' => trans('base.fecha_inicio'), 'visible' => true, 'sortable' => true, 'order' => 'desc'],
  		['id' => 'fin', 'label' => trans('base.fecha_fin'), 'visible' => true, 'sortable' => true],
      ['id' => 'duracion', 'label' => trans('base.duracion'), 'visible' => true, 'sortable' => false],
      ['id' => 'botones', 'label' => '', 'visible' => true, 'formatter' => 'botones', 'align' => 'right'],
    ];
    $selector = false;

    ob_start(); ?>
      var botones = '';
      if(!row.fin) row.fin = '';
      botones += '<button class="btn btn-primary btn-xs waves-effect" data-row-id="' + row.id + '" onclick="editar_fichaje(' + row.id + ', \'' + row.inicio.trim() + '\', \'' + row.fin.trim() + '\')"><?=trans('base.editar_fin')?></button> ';
      return botones.trim();
    <? $botones = ob_get_clean();

    $formatters = compact('botones');

    echo view('ui/datatable', compact('id', 'titulo', 'url', 'columnas', 'selector', 'formatters'));

  ?>
</div>

<script>

  $('document').ready(function(){
    $("#listado_fichajes-header").hide();
  });

  function editar_fichaje(id, inicio, fin){
    $('#editarFichaje input[name="id_fichaje"]').val(id);
    $('#editarFichaje input[name="inicio"]').val(inicio);
    $('#editarFichaje input[name="fin"]').val(fin);
    $('#editarFichaje').modal('show');
    eventos_editar_fichaje();
  }

</script>

<div class="col-sm-6">

  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('base.datos_trabajador')?></h2>
    </div>
    <div class="card-body card-padding">
      <form id="datos_trabajador" name="datos_trabajador" method="POST" ajax="true" action="<?=\URL::action('Trabajadores@postInfo')?>" onsubmit="return validar_datos_trabajador(this)">

        <input type="hidden" name="id" value="<?=$trabajador->id?>">
        <input type="hidden" name="operacion" value="datos_trabajador">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">

        <?

          $nombre = 'nombre';
          $label = trans('base.nombre');
          $valor = $trabajador->nombre;
          $requerido = true;
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido'));

					$nombre = 'apellidos';
          $label = trans('base.apellidos');
          $valor = $trabajador->apellidos;
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido'));

          $nombre = 'nif';
          $label = trans('base.nif');
          $valor = $trabajador->nif;
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido'));

          $nombre = 'centro_trabajo';
          $label = trans('base.centro_trabajo');
          $valor = $trabajador->centro_trabajo;
          echo view('ui/input', compact('nombre', 'label', 'valor'));

					$nombre = 'afiliacion';
          $label = trans('base.afiliacion');
          $valor = $trabajador->afiliacion;
          echo view('ui/input', compact('nombre', 'label', 'valor'));

          $id = 'hora_cierre';
          $nombre = 'hora_cierre';
          $label = trans('base.hora_cierre');
          $valor = $trabajador->hora_cierre;
          $validar = 'hora';
          echo view('ui/input', compact('id', 'nombre', 'label', 'valor', 'validar'));

          $id = 'hora_cierre_defecto';
          $nombre = 'hora_cierre_defecto';
          $label = trans('base.usar_hora_cierre_defecto');
          $valor = 'si';
          $checked = is_null($trabajador->hora_cierre);
          echo view('ui/checkbox', compact('id', 'nombre', 'label', 'valor', 'checked'));

          $id = 'cierre_automatico_horario';
          $nombre = 'cierre_automatico_horario';
          $label = trans('base.usar_cierre_automatico_horario');
          $valor = 'si';
          $checked = $trabajador->cierre_automatico_horario;
          echo view('ui/checkbox', compact('id', 'nombre', 'label', 'valor', 'checked'));
          
          $nombre = 'turno_maximo';
          $label = trans('base.turno_maximo');
          $valor = strval(floatval($trabajador->turno_maximo));
          $requerido = true;
					$validar = 'decimal';
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido', 'validar'));

          $id = 'cierre_automatico_turno';
          $nombre = 'cierre_automatico_turno';
          $label = trans('base.usar_cierre_automatico_turno');
          $valor = 'si';
          $checked = $trabajador->cierre_automatico_turno;
          echo view('ui/checkbox', compact('id', 'nombre', 'label', 'valor', 'checked'));

          echo view('ui/submit');

        ?>

        <script>

          $(document).ready(function(){
            $('#hora_cierre_defecto').change(function(){
              if(this.checked){
                $('#hora_cierre').val('');
                $('#hora_cierre').prop('readonly', true);
              } else {
                $('#hora_cierre').prop('readonly', false);
              }
            });
            $('#hora_cierre_defecto').trigger('change');
          });

          function validar_datos_trabajador(f){
            if(!f.hora_cierre_defecto.checked && f.hora_cierre.value.trim() == ''){ ui_error_validacion('<?=str_replace('[campo]', strtolower(trans('base.hora_cierre')), trans('validacion.campo_requerido'))?>'); return false; }
            return true;
          }

        </script>

      </form>
    </div>
  </div>

</div>

<div class="col-sm-6">

	<div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('base.contrato')?></h2>
    </div>
    <div class="card-body card-padding">
      <form id="contrato" name="contrato" method="POST" ajax="true" action="<?=\URL::action('Trabajadores@postInfo')?>">

        <input type="hidden" name="id" value="<?=$trabajador->id?>">
        <input type="hidden" name="operacion" value="contrato">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">

				<div class="col-sm-6 col-xs-6 m-l-0 p-l-0">
        <?
          $nombre = 'horas';
          $label = trans('base.horas');
          $valor = strval(floatval($trabajador->horas));
          $requerido = true;
					$validar = 'decimal';
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido', 'validar'));
				?>
				</div>
				<div class="col-sm-6 col-xs-6 m-r-0 p-r-0">
        <?
					$nombre = 'intervalo';
					$label = trans('base.intervalo');
					$opciones = array();
					$opciones[] = array('label' => trans('base.dia'), 'valor' => 'dia');
					$opciones[] = array('label' => trans('base.semana'), 'valor' => 'semana');
					$opciones[] = array('label' => trans('base.mes'), 'valor' => 'mes');
					$opciones[] = array('label' => trans('base.año'), 'valor' => 'año');
					$valor = $trabajador->intervalo;
					echo view('ui/select', compact('nombre', 'label', 'inline', 'requerido', 'opciones', 'valor'));
				?>
				</div>
        <div class="clear"></div>

				<?=view('ui/submit')?>

      </form>

      <script>
        function validar_pin(f){
          var pin = f.pin.value.trim();
          var regEx = /^[0-9]{4}$/i;
        	if(pin.search(regEx) == -1){
            swal('<?=trans('base.error')?>', '<?=trans('base.pin_incorrecto')?>', 'error'); return false;
            return false;
          }
        	else return true;
        }
      </script>

    </div>
  </div>

  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('base.pin_acceso')?></h2>
    </div>
    <div class="card-body card-padding">
      <form id="pin_acceso" name="pin_acceso" method="POST" ajax="true" action="<?=\URL::action('Trabajadores@postInfo')?>" onsubmit="return validar_pin(this)">

        <input type="hidden" name="id" value="<?=$trabajador->id?>">
        <input type="hidden" name="operacion" value="pin_acceso">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">

        <?

          $nombre = 'pin';
          $label = trans('base.pin');
          $valor = $trabajador->pin;
          $requerido = true;
          echo view('ui/input', compact('nombre', 'label', 'valor', 'requerido'));

          echo view('ui/submit');

        ?>

      </form>

      <script>
        function validar_pin(f){
          var pin = f.pin.value.trim();
          var regEx = /^[0-9]{4}$/i;
        	if(pin.search(regEx) == -1){
            swal('<?=trans('base.error')?>', '<?=trans('base.pin_incorrecto')?>', 'error'); return false;
            return false;
          }
        	else return true;
        }
      </script>

    </div>
  </div>

  <!-- 
  <div class="card">
    <div class="card-header bgm-bluegray">
      <h2><?=trans('base.avisos_fichajes')?></h2>
    </div>
    <div class="card-body card-padding p-t-10">
      <form id="avisos_fichajes" name="avisos_fichajes" method="POST" ajax="true" action="<?=\URL::action('Trabajadores@postInfo')?>" onsubmit="return validar_avisos_fichajes(this)">

        <input type="hidden" name="id" value="<?=$trabajador->id?>">
        <input type="hidden" name="operacion" value="avisos_fichajes">
        <input type="hidden" name="_token" value="<?=csrf_token()?>">

        <div class="p-t-10">

          <?

            $id = 'email_aviso';
            $nombre = 'email_aviso';
            $label = trans('base.email_aviso');
            $valor = $trabajador->email;
            $validar = 'email';
            echo view('ui/input', compact('id', 'nombre', 'label', 'valor', 'validar'));

            $avisos = json_decode($trabajador->avisos_turno_no_iniciado, true);
            if(is_null($avisos) || !is_array($avisos)) $avisos = ['lunes' => null, 'martes' => null, 'miercoles' => null, 'jueves' => null, 'viernes' => null, 'sabado' => null, 'domingo' => null];

            $i=0;
            foreach(['lunes', 'viernes', 'martes', 'sabado', 'miercoles', 'domingo', 'jueves'] as $dia){
              $i++;

          ?>
          <div class="col-xs-2 p-t-10 p-r-0 p-l-0">
            <p class="text-right m-b-0"><?=trans('base.'.$dia)?></p>
          </div>
          <div class="col-xs-1">
            <div class="checkbox <? if($dia == 'jueves') echo 'm-b-20'; ?>">
              <label class="" for="aviso_<?=$dia?>">
                <input type="checkbox" id="aviso_<?=$dia?>" value="si" name="aviso_<?=$dia?>" class="checkbox_aviso" <? if(!is_null($avisos[$dia])) echo 'checked="checked"'; ?>>
                <i class="input-helper"></i>
              </label>
              <div class="clearfix"></div>
            </div>
          </div>
          <div class="col-xs-3">
            <div class="form-group m-b-10">
              <div class="fg-line">
                <input id="hora_aviso_<?=$dia?>" type="text" class="form-control input-sm input-mask hora_aviso" data-mask="00:00" name="hora_aviso_<?=$dia?>" placeholder="hh:mm" <? if(!is_null($avisos[$dia])) echo 'value="'.$avisos[$dia].'"'; ?>>
              </div>
            </div>
          </div>
          <? if($i%2 == 0){ ?><div class="clearfix"></div><? }} ?>
          <div class="clearfix"></div>
        </div>

        <?

          $id = 'avisos_defecto';
          $nombre = 'avisos_defecto';
          $label = trans('base.usar_avisos_defecto');
          $valor = 'si';
          $checked = is_null($trabajador->avisos_turno_no_iniciado);
          echo view('ui/checkbox', compact('id', 'nombre', 'label', 'valor', 'checked'));

        ?>

        <script>

          $(document).ready(function(){
            $('.checkbox_aviso').change(function(){
              if(!this.checked){
                $('#hora_' + this.name).val('');
                $('#hora_' + this.name).prop('readonly', true);
              } else {
                $('#hora_' + this.name).prop('readonly', false);
              }
            });
            $('#avisos_defecto').change(function(){
              if(this.checked){
                $('.checkbox_aviso').prop('checked', false);
                $('.checkbox_aviso').prop('disabled', true);
                $('.hora_aviso').val('');
                $('.hora_aviso').prop('readonly', true);
              } else {
                $('.hora_aviso').prop('readonly', false);
                $('.checkbox_aviso').prop('disabled', false);
              }
            });
            $('.checkbox_aviso').trigger('change');
            $('#avisos_defecto').trigger('change');
          });

          function validar_avisos_fichajes(f){
            if(f.email_aviso.value.trim() == ''){ ui_error_validacion('<?=trans('base.email_aviso_vacio')?>'); return false; }
            if(!validar_email(f.email_aviso.value.trim())){ ui_error_validacion('<?=trans('base.email_aviso_invalido')?>'); return false; }
            <? foreach(['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo'] as $dia){ ?>
            if(f.aviso_<?=$dia?>.checked){
              if(f.hora_aviso_<?=$dia?>.value.trim() == ''){ ui_error_validacion('<?=trans('base.hora_dia_vacio', ['dia' => trans('base.'.$dia)])?>'); return false; }
              if(!validar_hora(f.hora_aviso_<?=$dia?>.value.trim())){ ui_error_validacion('<?=trans('base.hora_dia_invalida', ['dia' => trans('base.'.$dia)])?>'); return false; }
            }
            <? } ?>
            return true;
          }

        </script>

        <? echo view('ui/submit'); ?>

      </form>
    </div>
  </div> 
  -->

</div>
