<?=view('login/cabecera')?>
<body class="login-content">

  <!-- Login -->
  <div class="lc-block toggled" id="l-login">
    <p class="text-left"><?=trans('login.instrucciones_olvido')?></p>
    <form name="login" method="post" action="<?=\URL::action('Login@postOlvido')?>" onsubmit="return validar(this)">
      <input type="hidden" name="_token" value="<?=csrf_token()?>">

      <div class="input-group m-b-20">
        <span class="input-group-addon"><i class="md md-email"></i></span>
        <div class="fg-line">
          <input name="email" type="text" class="form-control" placeholder="<?=trans('login.email')?>">
        </div>
      </div>

      <a class="btn btn-login btn-danger btn-float bgm-green" onclick="$('input#olvido').trigger('click');"><i class="md md-arrow-forward"></i></a>
      <input type="submit" id="login" style="display:none">
    </form>

    <script>

      function validar(f){
        if(f.email.value.trim() == ''){ swal('oops!', '<?=trans('login.email_vacio')?>', 'error'); return false; }
        if(!validar_email(f.email.value.trim())){ swal('oops!', '<?=trans('login.email_invalido')?>', 'error'); return false; }
        return true;
      }

      $(document).ready(function(){ <?
        if(\Session::has('success')){ ?> swal('<?=trans('login.ook')?>', '<?=\Session::get('success')?>', 'success'); <? \Session::forget('success'); }
        if(\Session::has('error')){ ?> swal('<?=trans('login.ops')?>', '<?=\Session::get('error')?>', 'error'); <? \Session::forget('error'); }
      ?> });

    </script>

    <ul class="login-navigation">
      <a href="<?=\URL::action('Login@getIndex')?>" class="btn bgm-blue waves-effect waves-button waves-float"><?=trans('login.volver')?></a>
    </ul>
  </div>

  <?=view('ui/navegador_viejo')?>

  <!-- Javascript Libraries -->
  <script src="<?=asset('vendors/bower_components/jquery/dist/jquery.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/bootstrap/dist/js/bootstrap.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/Waves/dist/waves.min.js')?>"></script>

  <!-- Placeholder for IE9 -->
  <!--[if IE 9 ]>
    <script src="<?=asset('vendors/bower_components/jquery-placeholder/jquery.placeholder.min.js')?>"></script>
  <![endif]-->

  <script src="<?=asset('js/functions.js')?>"></script>

</body>
</html>
