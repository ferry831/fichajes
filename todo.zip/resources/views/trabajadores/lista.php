<div class="block-header">
  <h2><?=trans('base.gestion_trabajadores')?></h2>
  <div class="actions">
    <button class="btn btn-primary waves-effect" data-toggle="modal" href="#nuevoTrabajador"><?=trans('base.nuevo_trabajador')?></button>
  </div>
</div>
<?=view('trabajadores/nuevo')?>

<?php

  // datatable

	$id = 'listado_trabajadores';
	$titulo = trans('base.listado_trabajadores');
	$url = \URL::action('Trabajadores@postListadoTrabajadores');
  $columnas = [
    ['id' => 'id', 'label' => '', 'visible' => false, 'identifier' => true],
    ['id' => 'nombre', 'label' => trans('base.nombre'), 'visible' => true, 'sortable' => true, 'searchable' => true, 'order' => 'asc'],
		['id' => 'apellidos', 'label' => trans('base.apellidos'), 'visible' => true, 'sortable' => true, 'searchable' => true],
    ['id' => 'nif', 'label' => trans('base.nif'), 'visible' => true, 'sortable' => true, 'searchable' => true],
    ['id' => 'estado', 'label' => trans('base.estado'), 'visible' => true, 'sortable' => false, 'searchable' => false, 'align' => 'center'],
    ['id' => 'inicio', 'label' => trans('base.inicio_turno'), 'visible' => true, 'sortable' => false, 'searchable' => false],
    ['id' => 'fin', 'label' => trans('base.fin_turno'), 'visible' => true, 'sortable' => false, 'searchable' => false],
    ['id' => 'duracion', 'label' => trans('base.duracion'), 'visible' => true, 'sortable' => false, 'searchable' => false],
    ['id' => 'botones', 'label' => '', 'visible' => true, 'formatter' => 'botones', 'align' => 'right'],
  ];
  $selector = false;

  ob_start(); ?>
    var botones = '';
    botones += '<button class="btn btn-danger btn-xs waves-effect" data-row-id="' + row.id + '" onclick="eliminar(' + row.id + ')"><i class="md md-delete"></i> <?=trans('base.borrar')?></button> ';
    botones += '<button class="btn btn-primary btn-xs waves-effect" data-row-id="' + row.id + '" onclick="info_trabajador(' + row.id + ')"><i class="md md-info"></i> <?=trans('base.info')?></button> ';
    return botones.trim();
  <? $botones = ob_get_clean();

  $formatters = compact('botones');

  echo view('ui/datatable', compact('id', 'titulo', 'url', 'columnas', 'selector', 'formatters'));

?>

<script>

  function info_trabajador(id){
    document.location.href = '<?=\URL::action('Trabajadores@getInfo')?>/' + id;
  }

  function eliminar(id){
    swal({
      title: "<?=trans('base.estas_seguro')?>",
      text: "<?=trans('base.no_undo')?>",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#DD6B55",
      confirmButtonText: "<?=trans('base.si')?>",
      cancelButtonText: "<?=trans('base.no')?>",
      closeOnConfirm: false
    }, function(){
      $.post(
        '<?=\URL::action('Trabajadores@postEliminar')?>',
        {id: id, _token: '<?=csrf_token()?>'},
        function(r){
          if(r != "") swal("<?=trans('base.error')?>", r, "error");
          else {
            $("#listado_trabajadores").bootgrid("reload");
            swal.close();
            info('<?=trans('base.trabajador_eliminado')?>', '<?=trans('base.cerrar')?>');
          }
        }
      );
    });
  }

  $(document).ready(function(){
    setInterval(function(){
      $('#listado_trabajadores').bootgrid('reload');
    }, 60 * 1000);
  });

</script>
