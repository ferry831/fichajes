<!DOCTYPE html>
<!--[if IE 9 ]><html class="ie9"><![endif]-->
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?=\Config::get('app.nombre', 'Material Admin')?></title>

  <!-- Vendor CSS -->
  <link href="<?=asset('vendors/bower_components/animate.css/animate.min.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/bower_components/sweetalert/dist/sweetalert-override.min.css')?>" rel="stylesheet">
  <link href="<?=asset('vendors/bower_components/material-design-iconic-font/css/material-design-iconic-font.min.css')?>" rel="stylesheet">

  <!-- CSS -->
  <link href="<?=asset('css/app.min.1.css')?>" rel="stylesheet">
  <link href="<?=asset('css/app.min.2.css')?>" rel="stylesheet">
  <link href="<?=asset('css/material.css')?>" rel="stylesheet">

  <!-- Javascript Libraries -->
  <script src="<?=asset('vendors/bower_components/jquery/dist/jquery.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/bootstrap/dist/js/bootstrap.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/Waves/dist/waves.min.js')?>"></script>
  <script src="<?=asset('vendors/bower_components/sweetalert/dist/sweetalert.min.js')?>"></script>

  <!-- Placeholder for IE9 -->
  <!--[if IE 9 ]>
    <script src="<?=asset('vendors/bower_components/jquery-placeholder/jquery.placeholder.min.js')?>"></script>
  <![endif]-->

  <script src="<?=asset('js/functions.js')?>"></script>
  <script src="<?=asset('js/utiles.js')?>"></script>

</head>
