function ui_validar_formulario(form){

  var inputs = [];
  $(form).find('input[type="text"], input[type="password"], textarea, select, input[type="checkbox"], fieldset.radio').each(function(){ inputs.push($(this)); });

  for(var i=0; i<inputs.length; i++){
    var input = inputs[i];

    // comprobamos si es un campo requerido
    var requerido = input.attr('requerido');
    if(typeof requerido != 'undefined' && requerido == 'si'){

      var texto_requerido = input.attr('texto-requerido');
      if(input.prop('tagName') == 'INPUT' && input.prop('type') == 'checkbox'){

        if(!input.prop('checked')){
          if(typeof texto_requerido == 'undefined' || texto_requerido == ''){
            var campo = input.attr('campo');
            texto_requerido = ui_check_requerido.replace('[campo]', campo.toLowerCase());
          }
          ui_error_validacion(texto_requerido);
          return false;
        }

      } else {
        if(input.prop('tagName') == 'FIELDSET'){

          if(input.find('input[type="radio"]:checked').length == 0){
            if(typeof texto_requerido == 'undefined' || texto_requerido == ''){
              var campo = input.attr('campo');
              texto_requerido = ui_radio_requerido.replace('[campo]', campo.toLowerCase());
            }
            ui_error_validacion(texto_requerido);
            return false;
          }

        } else {

          if(input.val().trim() == ''){
            if(typeof texto_requerido == 'undefined' || texto_requerido == ''){
              var campo = input.attr('campo');
              texto_requerido = ui_campo_requerido.replace('[campo]', campo.toLowerCase());
            }
            ui_error_validacion(texto_requerido);
            return false;
          }

        }
      }

    } // fin campo requerido

    var validar = input.attr('validar');
    if((typeof validar != 'undefined' && validar != '') && input.val().trim() != ''){
      var error = '';
      var campo = input.attr('campo');
      switch(validar){
        case 'entero':
          if(!validar_entero(input.val().trim()))
            error = ui_entero_invalido.replace('[campo]', campo.toLowerCase());
        break;
        case 'decimal':
          if(!validar_decimal(input.val().trim()))
            error = ui_decimal_invalido.replace('[campo]', campo.toLowerCase());
        break;
        case 'email':
          if(!validar_email(input.val().trim()))
            error = ui_email_invalido.replace('[campo]', campo.toLowerCase());
        break;
        case 'fecha':
          if(!validar_fecha(input.val().trim()))
            error = ui_fecha_invalida.replace('[campo]', campo.toLowerCase());
        break;
        case 'hora':
          if(!validar_hora(input.val().trim()))
            error = ui_hora_invalida.replace('[campo]', campo.toLowerCase());
        break;
        case 'fecha_hora':
          if(!validar_fecha_hora(input.val().trim()))
            error = ui_fecha_hora_invalida.replace('[campo]', campo.toLowerCase());
        break;
      }
      if(error != ''){
        ui_error_validacion(error);
        return false;
      }
    }

  }

  var onsubmit = $(form).attr('postonsubmit');
  if(typeof onsubmit != 'undefined' && onsubmit != ''){
    var form = $(form)[0];
    var validacion_onsubmit = eval('(function() {' + onsubmit.replace('this', 'form') + '}())');
    if(!validacion_onsubmit) return false;
  }

  var ajax = $(form).attr('ajax');
  var onajax = $(form).attr('onajax');
  if(typeof ajax != 'undefined' && ajax != ''){
    if(ajax == 'true' || ajax == 'si') ajax = ui_cambios_guardados;
    $.post(
      $(form)[0].action,
      $(form).serializeObject(),
      function(r){
        if(r != "") ui_error_validacion(r);
        else { 
          ui_info(ajax);
          if(typeof onajax != 'undefined' && onajax != ''){
            eval('(function() {' + onajax + '}())');
          }
        }
      }
    );
    return false;
  }

  return true;

}

function validar_ui(){
  $('form').each(function(){
    var form = $(this);
    var onsubmit = form.attr('onsubmit');
    if(typeof onsubmit != 'undefined' && onsubmit != '') form.attr('postonsubmit', onsubmit);
    form.attr('onsubmit', 'return ui_validar_formulario(this)');
  });
}

$(document).ready(validar_ui);
