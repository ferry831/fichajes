<?php namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel {

	/**
	 * The Artisan commands provided by your application.
	 *
	 * @var array
	 */
	protected $commands = [
		'App\Console\Commands\CierreAutomatico'
	];

	/**
	 * Define the application's command schedule.
	 *
	 * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
	 * @return void
	 */
	protected function schedule(Schedule $schedule){
		//$schedule->call(function(){ \App\Models\Trabajador::enviarAvisos(); })->cron('*/30 * * * *')->name('enviar_avisos')->withoutOverlapping();
		//$schedule->call(function(){ \App\Models\Fichaje::cerrarAbiertos(); })->cron('*/10 * * * *')->name('cerrar_abiertos')->withoutOverlapping();
		$schedule->command('cierre_automatico')->cron('*/10 * * * *')->withoutOverlapping();
	}

}
