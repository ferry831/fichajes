<?php

  if(!isset($id)) 				$id = 'input-'.md5(microtime().rand(0, 999999));
	if(!isset($nombre)) 		$nombre = '';
	if(!isset($valor)) 			$valor = '';
	if(!isset($label)) 			$label = '';
  if(!isset($campo)) 			$campo = '';
	if(!isset($disabled)) 	$disabled = false;
	if(!isset($requerido)) 	$requerido = false; // o true o texto de validacion
  if(!isset($checked))		$checked = false;
	if(!isset($inline))			$inline = false;
  if(!isset($clases))			$clases = [];

  if($campo == '') $campo = $label;

  $mb = false;
  foreach($clases as $clase){
    if(strpos($clase, 'm-b-') !== false) $mb = true;
  }
  if(!$mb) $clases[] = 'm-b-30';

?>
<div class="checkbox <?($disabled)?'disabled':''?> <?=implode(' ', $clases)?>">
  <label class="<?=($inline)?'col-sm-offset-3 col-sm-9':''?>" for="<?=htmlentities($id)?>">
    <input type="checkbox" id="<?=htmlentities($id)?>" value="<?=htmlentities($valor)?>" campo="<?=htmlentities($campo)?>"
      <? if($disabled) 							echo 'disabled="disabled" '; ?>
      <? if($checked) 							echo 'checked="checked" '; ?>
      <? if($nombre != '') 					echo 'name="'.htmlentities($nombre).'" '; ?>
      <? if($requerido !== false) 	echo 'requerido="si" '; ?>
      <? if(is_string($requerido))	echo 'texto-requerido="'.htmlentities($requerido).'" '?>
      >
      <i class="input-helper"></i>
      <?=$label?>
  </label>
  <div class="clearfix"></div>
</div>
