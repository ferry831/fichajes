<?php

	// aquí se definen todos los permisos posibles, organizados por secciones.
	// el permiso se define por la clave del array dentro del array de la sección, el valor es meramente descriptivo
	// de hecho no se utiliza para nada, el texto mostrado en la gestión de usuarios se obtiene del fichero de idioma 'permisos.php'

	return array(

		'lista' => [

			'basicos' => [
				'admin' => 'administrador (todos los permisos)',
				'inicio_sesion' => 'iniciar sesión',
			],

			'configuracion' => [
				'gestion_usuarios' => 'gestión de usuarios',
			],

		],

		// a partir de ahora se especifican permisos especificos por perfil

		'administrador' => [

			'basicos' => [
				'gestion_administradores' => 'gestión de administradores',
			],

		],

	);
