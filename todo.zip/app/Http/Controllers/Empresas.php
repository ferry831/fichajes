<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;

class Empresas extends Controller {

	public static $perfiles = ['administrador'];
	public static $permisos = [];

	public function getIndex(){

		$params = [
			'menu' => 'empresas',
			'submenu' => '',
			'contenido' => view('empresas/lista'),
		];
		return view('plantilla', $params);

	}

	public function postListadoEmpresas(){

		$output = new \stdClass();
		$output->current = \Input::get('current');
		$output->rowCount = \Input::get('rowCount');
		$output->rows = array();
		$output->total = 0;

		$sql = 'select count(*) as c from empresas where 1';

		$res = \DB::select($sql);
		if(isset($res[0]->c)) $output->total = $res[0]->c;

		$params = array();

		if(trim(\Input::get('searchPhrase')) != ''){
			$sql .= ' and (razon_social like ? or cif like ?)';
			$params[] = '%'.trim(\Input::get('searchPhrase')).'%';
			$params[] = '%'.trim(\Input::get('searchPhrase')).'%';
		}

		$sort = \Input::get('sort');
		if(count($sort) > 0){
			$orden = array();
			foreach($sort as $id => $direccion){
				switch($id){
					case 'razon_social': $orden[] = 'razon_social '.$direccion; break;
					case 'cif': $orden[] = 'cif '.$direccion; break;
				}
			}
			$sql .= ' order by '.implode(', ', $orden);
		}

		$sql = str_replace('count(*) as c', 'id, razon_social, cif', $sql);
		if(\Input::get('rowCount') > 0) $sql .= ' limit '.((\Input::get('current') - 1) * \Input::get('rowCount')).', '.(\Input::get('rowCount'));

		$resultados = \DB::select($sql, $params);
		if(count($resultados) > 0){
			foreach($resultados as $r){
				$r->botones = '';
				$output->rows[] = $r;
			}
		}

		return \Response::json($output);

	}

	public function postNuevaEmpresa(){

		try {
			$empresa = new \App\Models\Empresa;
			$empresa->razon_social = \Input::get('razon_social');
			$empresa->cif = \Input::get('cif');
			$empresa->centro_trabajo = \Input::get('centro_trabajo');
			$empresa->ccc = \Input::get('ccc');
			$empresa->pin = rand(1000, 9999);
			$empresa->token_autologin = \App\Models\Empresa::generarTokenAutologin();
			$empresa->save();
		} catch(\Exception $e){
			\Session::put('error', trans('base.error_creando_empresa'));
			return \Redirect::action('Empresas@getIndex');
		}

		\Session::put('info', trans('base.empresa_creada'));

		try {
			$usuario = new \App\Models\Usuario;
			$usuario->email = \Input::get('email');
			$usuario->password = bcrypt(\Input::get('password'));
			$usuario->perfil = 'empresa';
			$usuario->save();
			$usuario->setPermiso('inicio_sesion');
		} catch(\Exception $e){
			\Session::put('error', trans('base.error_creando_usuario'));
			return \Redirect::action('Empresas@getInfo', [$empresa->id]);
		}

		try {
			$usuario_empresa = new \App\Models\UsuarioEmpresa;
			$usuario_empresa->id_usuario = $usuario->id;
			$usuario_empresa->id_empresa = $empresa->id;
			$usuario_empresa->save();
		} catch(\Exception $e){
			$usuario->delete();
			\Session::put('error', trans('base.error_creando_usuario'));
			return \Redirect::action('Empresas@getInfo', [$empresa->id]);
		}

		return \Redirect::action('Empresas@getInfo', [$empresa->id]);

	}

	public function getInfo($id = 0){
		try {
			$empresa = \App\Models\Empresa::findOrFail($id);
			$params = [
				'menu' => 'empresas',
				'submenu' => '',
				'contenido' => view('empresas/info', compact('empresa')),
			];
			return view('plantilla', $params);
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			\Session::put('error', trans('base.empresa_desconocida'));
			return \Redirect::action('Empresas@getIndex');
		}
	}

	public function postInfo(){
		$salida = '';
		try {

			$empresa = \App\Models\Empresa::findOrFail(\Input::get('id'));
			switch(\Input::get('operacion')){

				case 'datos_empresa':
					$empresa->razon_social = \Input::get('razon_social');
					$empresa->cif = \Input::get('cif');
					$empresa->centro_trabajo = \Input::get('centro_trabajo');
					$empresa->ccc = \Input::get('ccc');
					$empresa->hora_cierre = \Input::get('hora_cierre');
					$empresa->save();
				break;

				case 'pin_acceso':
					$empresa->pin = \Input::get('pin');
					$empresa->save();
				break;

				case 'avisos_fichajes':
					$avisos = ['lunes' => null, 'martes' => null, 'miercoles' => null, 'jueves' => null, 'viernes' => null, 'sabado' => null, 'domingo' => null];
					foreach($avisos as $dia => $valor){
						if(\Input::has('hora_aviso_'.$dia)){
							$avisos[$dia] = \Input::get('hora_aviso_'.$dia);
						}
					}
					$empresa->avisos_turno_no_iniciado = json_encode($avisos);
					$empresa->save();
				break;

				case 'regenerar_token_autologin':
					$empresa->token_autologin = \App\Models\Empresa::generarTokenAutologin();
					$empresa->save();
					\Session::put('info', trans('base.url_regenerada'));
					return redirect()->back();
				break;

				case 'guardar_alias_autologin':

					$alias = trim(\Input::get('alias_autologin'));
					
					if($alias == ''){

						$empresa->alias_autologin = null;
						$empresa->save();
						\Session::put('info', trans('base.cambios_guardados'));
						return redirect()->back();

					} else {

						if(!ctype_alnum($alias)){
							\Session::put('error', trans('base.alias_no_valido'));
							return redirect()->back();
						}

						$duplicado = \App\Models\Empresa::where('id', '<>', $empresa->id)->where('alias_autologin', $alias)->first();
						if(!is_null($duplicado)){
							
							\Session::put('error', trans('base.alias_duplicado'));
							return redirect()->back();
							
						} else {
							
							$empresa->alias_autologin = $alias;
							$empresa->save();
							\Session::put('info', trans('base.cambios_guardados'));
							return redirect()->back();

						}

					}
					
				break;

				case 'guardar_logo':

					$validator = \Validator::make(\Input::all(), [
						'logo' => 'required|image|max:2048'
					]);

					if ($validator->fails()){
						\Session::put('error', trans('base.imagen_no_valida'));
						return redirect()->back();
					}

					do {
						$nombre = uniqid().'.png';
					} while(\App\Models\Empresa::where('logo', $nombre)->count() > 0);

					if($empresa->logo != '' && file_exists(public_path('logo/'.$empresa->logo))){
						unlink(public_path('logo/'.$empresa->logo));
					}

					$empresa->logo = $nombre;
					$empresa->save();

					\Image::make(\Input::file('logo'))->save(public_path('logo/'.$empresa->logo));

					\Session::put('info', trans('base.cambios_guardados'));
					return redirect()->back();

				break;

				case 'eliminar_logo':

					if($empresa->logo != '' && file_exists(public_path('logo/'.$empresa->logo))){
						unlink(public_path('logo/'.$empresa->logo));
					}

					$empresa->logo = '';
					$empresa->save();

					\Session::put('info', trans('base.cambios_guardados'));
					return redirect()->back();

				break;

			}

		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.empresa_desconocida');
		} catch(\Illuminate\Database\QueryException $e){
			$salida = trans('base.empresa_duplicada');
		} catch(\Exception $ex){
			$salida = trans('base.error_inesperado').$ex->getMessage();
		}
		return \Response::json($salida);
	}

	public function postNuevoUsuario(){
		try {
			$empresa = \App\Models\Empresa::findOrFail(\Input::get('id_empresa'));
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			\Session::put('error', trans('base.empresa_desconocida'));
			return \Redirect::action('Empresas@getIndex');
		}
		try {
			$usuario = new \App\Models\Usuario;
			$usuario->nombre = \Input::get('nombre');
			$usuario->apellidos = \Input::get('apellidos');
			$usuario->email = \Input::get('email');
			$usuario->password = bcrypt(\Input::get('password'));
			$usuario->perfil = 'empresa';
			$usuario->save();
			$usuario_empresa = new \App\Models\UsuarioEmpresa;
			$usuario_empresa->id_usuario = $usuario->id;
			$usuario_empresa->id_empresa = $empresa->id;
			$usuario_empresa->save();
			$usuario->setPermiso('inicio_sesion');
		} catch(\Illuminate\Database\QueryException $e){
			\Session::put('error', trans('base.usuario_existe'));
			return \Redirect::action('Empresas@getInfo', [$empresa->id]);
		}
		return \Redirect::action('Empresas@getInfo', [$empresa->id]);
	}

	public function postActivarUsuario(){
		$salida = '';
		try {
			$empresa = \App\Models\Empresa::findOrFail(\Input::get('id_empresa'));
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.empresa_desconocida');
			return \Response::json($salida);
		}
		try {
			$usuario = \App\Models\Usuario::findOrFail(\Input::get('id_usuario'));
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.usuario_desconocido');
			return \Response::json($salida);
		}
		if($salida == ''){
			if(\App\Models\UsuarioEmpresa::whereRaw('id_usuario=? and id_empresa=?', [$usuario->id, $empresa->id])->count() == 0){
				$salida = trans('base.usuario_desconocido');
			} else {
				if($usuario->puede('inicio_sesion')){
					$usuario->unsetPermiso('inicio_sesion');
					\Session::put('info', trans('base.usuario_bloqueado'));
				} else {
					$usuario->setPermiso('inicio_sesion');
					\Session::put('info', trans('base.usuario_activado'));
				}
			}
		}
		return \Response::json($salida);
	}

	public function postEliminarUsuario(){
		$salida = '';
		try {
			$empresa = \App\Models\Empresa::findOrFail(\Input::get('id_empresa'));
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.empresa_desconocida');
			return \Response::json($salida);
		}
		try {
			$usuario = \App\Models\Usuario::findOrFail(\Input::get('id_usuario'));
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.usuario_desconocido');
			return \Response::json($salida);
		}
		if($salida == ''){
			if(\App\Models\UsuarioEmpresa::whereRaw('id_usuario=? and id_empresa=?', [$usuario->id, $empresa->id])->count() == 0){
				$salida = trans('base.usuario_desconocido');
			} else {
				$usuario->delete();
				\Session::put('info', trans('base.usuario_eliminado'));
			}
		}
		return \Response::json($salida);
	}

	public function postInfoUsuario(){
		$salida = '';
		try {
			$empresa = \App\Models\Empresa::findOrFail(\Input::get('id_empresa'));
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			\Session::put('error', trans('base.empresa_desconocida'));
			return redirect()->back();
		}
		try {
			$usuario = \App\Models\Usuario::findOrFail(\Input::get('id_usuario'));
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			\Session::put('error', trans('base.usuario_desconocido'));
			return redirect()->back();
		}
		if(\App\Models\UsuarioEmpresa::whereRaw('id_usuario=? and id_empresa=?', [$usuario->id, $empresa->id])->count() == 0){
			\Session::put('error', trans('base.usuario_desconocido'));
			return redirect()->back();
		}
		try {
			$usuario->nombre = \Input::get('nombre');
			$usuario->apellidos = \Input::get('apellidos');
			$usuario->email = \Input::get('email');
			if(\Input::has('password') && trim(\Input::get('password')) != '') $usuario->password = bcrypt(\Input::get('password'));
			$usuario->save();
			\Session::put('info', trans('base.usuario_modificado'));
		} catch (\Illuminate\Database\QueryException $e){
			\Session::put('error', trans('base.usuario_existe'));
		}
		return redirect()->back();
	}

	public function postEliminar(){
		$salida = '';
		try {
			$empresa = \App\Models\Empresa::findOrFail(\Input::get('id'));
			$sql = 'select id_usuario from usuarios_empresa where id_empresa=?';
			$usuarios = \DB::select($sql, [$empresa->id]);
			foreach($usuarios as $usuario){
				$usuario = \App\Models\Usuario::find($usuario->id_usuario);
				if(!is_null($usuario)) $usuario->delete();
			}
			$empresa->delete();
		} catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e){
			$salida = trans('base.empresa_desconocida');
		}
		return \Response::json($salida);
	}

}
