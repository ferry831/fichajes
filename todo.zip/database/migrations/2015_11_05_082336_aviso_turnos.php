<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AvisoTurnos extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up(){
		Schema::table('empresas', function($table){
			$table->text('avisos_turno_no_iniciado')->after('hora_cierre');
		});
		Schema::table('trabajadores', function($table){
			$table->text('avisos_turno_no_iniciado')->nullable()->after('hora_cierre');
			$table->string('email')->after('avisos_turno_no_iniciado');
		});
		Schema::create('avisos', function(Blueprint $table){
			$table->bigIncrements('id');
			$table->bigInteger('id_trabajador')->unsigned()->index();
			$table->foreign('id_trabajador')->references('id')->on('trabajadores')->onDelete('cascade');
			$table->date('fecha');
		});
	}

	/**
		* Reverse the migrations.
		*
		* @return void
		*/
	public function down(){
		Schema::table('empresas', function($table){
			$table->dropColumn('avisos_turno_no_iniciado');
		});
		Schema::table('trabajadores', function($table){
			$table->dropColumn('avisos_turno_no_iniciado');
			$table->dropColumn('email');
		});
		Schema::drop('avisos');
	}

}
